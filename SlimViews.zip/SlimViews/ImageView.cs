﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViewer
 * FILE:        ImageView.cs
 * PURPOSE:     Main ViewModel. Acts as the "Traffic Controller" connecting:
 *              1. The View (UI Binding)
 *              2. The Data Contexts (File, Image, UI State)
 *              3. The Tool State (DrawingState)
 * PROGRAMMER:  Peter Geinitz (Wayfarer)
 */

// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable MemberCanBeInternal
// ReSharper disable UnusedMember.Global

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Collections.Immutable;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Common.Dialogs;
using Common.Images;
using Extended.Extensions;
using Extended.Objects;
using FileHandler;
using Imaging;
using Imaging.Cifs;
using Imaging.Enums;
using Imaging.Gifs;
using Imaging.Objects.Documents;
using Imaging.Objects.Shapes;
using SlimControls;
using SlimViews.Contexts;
using ViewModel;
using Point = System.Windows.Point;

namespace SlimViews
{
    /// <summary>
    /// Main View for SlimViewer. This class is the central hub that connects the UI, the data contexts, and the drawing state.
    /// </summary>
    /// <seealso cref="ViewModel.ViewModelBase" />
    public sealed class ImageView : ViewModelBase
    {
        // --- 1. CONTEXTS & STATE (The Data Layer) ---

        /// <summary>
        /// The Single Source of Truth for Drawing Tools, Colors, and Modes.
        /// </summary>
        public DrawingState MyDrawingState { get; set; } = new DrawingState();

        //--- Internal Contexts (Data Holders) ---

        /// <summary>
        /// The image Context, holding all image-related data and operations.
        /// For Databinding it needs to be a Property.
        /// </summary>
        /// <value>
        /// The image.
        /// </value>
        public ImageContext Image { get; } = new();

        /// <summary>
        /// The UI state Context, holding all UI-related state (button visibility, status images, etc).
        /// For Databinding leave it as Property!
        /// </summary>
        /// <value>
        /// The state of the UI.
        /// </value>
        public UiState UiState { get; } = new();

        /// <summary>
        /// The file context, holding all file-related data (current path, list of files, observer for navigation).
        /// For Databinding leave it as Property!
        /// </summary>
        /// <value>
        /// The file context.
        /// </value>
        public FileContext FileContext { get; } = new();

        /// <summary>
        /// Commands handler for this view.
        /// </summary>
        /// <value>
        /// The commands.
        /// </value>
        public ImageViewCommands Commands { get; }

        /// <summary>
        /// Gets the history manager.
        /// </summary>
        /// <value>
        /// The history manager.
        /// </value>
        private LayerDocumentController? _layers;

        /// <summary>
        /// Gets the layered document controller for the currently open image, or null when the image is
        /// still a single flat bitmap (the common case: opening a file never creates one). Once non-null,
        /// pencil/eraser strokes, shape tools, and fill/texture/filter all target the active layer instead
        /// of <see cref="Contexts.ImageContext.Bitmap"/> directly, and Save flattens the document. Bind
        /// <c>ImageZoom.LayeredDocument</c> to <c>Layers.Document</c> to display it (see MainWindow.xaml);
        /// once <see cref="Layers"/> is set, ImageZoom handles rendering on its own from then on, including
        /// picking up every subsequent edit - nothing further needs to be pushed to it from here. Turn it on
        /// with <see cref="EnableLayers"/> (for example from a "Layers" panel's own "Enable" button).
        /// </summary>
        public LayerDocumentController? Layers
        {
            get => _layers;
            private set
            {
                _layers = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Turns the currently open single bitmap into a layered document (one "Background" raster layer,
        /// pixel-identical to what was on screen) and switches editing over to it. Calling this again while
        /// already enabled does nothing.
        /// </summary>
        public void EnableLayers()
        {
            if (Layers is not null || Image.Bitmap is null) return;

            var controller = LayerDocumentController.FromBitmap(Image.Bitmap);
            controller.DocumentChanged += (_, _) => RefreshFromLayers();
            controller.ActiveLayerChanged += (_, _) => UpdateActiveLayerGating();
            Layers = controller;
            UpdateActiveLayerGating();
        }

        /// <summary>
        /// Drops the layered document (after flattening it into <see cref="Contexts.ImageContext.Bitmap"/>, so
        /// nothing visible changes) and returns to single-bitmap editing. The layer history is discarded;
        /// this is meant for "I don't need layers for this image after all", not a reversible action.
        /// </summary>
        public void DisableLayers()
        {
            if (Layers is null) return;

            var controller = Layers;
            Layers = null;
            UpdateActiveLayerGating();

            Image.Bitmap = controller.Flatten();
            Image.BitmapImage = Image.Bitmap?.ToBitmapSource();
            controller.Dispose();
        }

        /// <summary>
        /// Discards any layered document for the image that is about to be replaced, without touching
        /// <see cref="Contexts.ImageContext"/> - callers that load a new image set <see cref="Contexts.ImageContext.Bitmap"/>
        /// themselves right after. A leftover controller from the previous image must not silently keep
        /// intercepting strokes/shapes/undo for a file that no longer matches it.
        /// </summary>
        private void ResetLayers()
        {
            if (Layers is null) return;

            Layers.Dispose();
            Layers = null;
            UpdateActiveLayerGating();
        }

        /// <summary>
        /// Recomputes <see cref="DrawingState.IsActiveLayerRaster"/> from the current <see cref="Layers"/>
        /// state: true (fully enabled) with no layered document open, since single-bitmap editing has no
        /// "active layer" restriction at all; otherwise true only while the active layer is a
        /// <see cref="RasterLayer"/>. Called once whenever layers are turned on/off and every time
        /// <see cref="LayerDocumentController.ActiveLayerChanged"/> fires - which covers a user picking a
        /// different layer in the Layers panel as well as the active layer changing as a side effect of
        /// another edit (e.g. <see cref="LayerDocumentController.RemoveLayer"/> reassigning it).
        /// </summary>
        private void UpdateActiveLayerGating()
        {
            var isRaster = Layers is null
                           || (Layers.ActiveLayerId is { } id && Layers.Document.FindLayer(id) is RasterLayer);

            MyDrawingState.IsActiveLayerRaster = isRaster;

            if (isRaster) return;

            // The active layer just became (or already was, e.g. right after EnableLayers on an image whose
            // very first layer somehow is not raster) a shape layer while a pixel-only tool/mode was
            // selected. Disabling the toolbar button (see DrawingToolBarControl.xaml) only stops the user
            // from switching TO it - it does not un-select a tool that was already active, and the canvas
            // itself has no gating of its own, so a stroke would otherwise silently do nothing (Pencil/
            // Eraser, via DrawStrokeAsync) or throw and get swallowed (Clear, via ApplyToActiveRasterLayer -
            // see SelectedFrameAction's catch). Switch away from both so neither can happen.
            if (MyDrawingState.ActiveTool is DrawTool.Pencil or DrawTool.Eraser)
            {
                MyDrawingState.ActiveTool = DrawTool.Move;
            }

            if (MyDrawingState.ActiveAreaMode == AreaMode.Erase)
            {
                MyDrawingState.ActiveAreaMode = AreaMode.Fill;
            }
        }

        /// <summary>
        /// Re-flattens <see cref="Layers"/> and pushes the result to <see cref="Contexts.ImageContext"/> so
        /// anything still reading <c>Image.Bitmap</c>/<c>Image.BitmapImage</c> directly (Save, Compare, the
        /// whole-image filter menu, ...) sees the current, edited state. <see cref="Common.Images.ImageZoom"/>
        /// itself does not need this - its <c>LayeredDocument</c> binding re-flattens on its own from
        /// <see cref="LayerDocumentController.Document"/>'s own change notification - but everything else in
        /// this class that was written against a single bitmap still expects one to exist.
        /// </summary>
        private void RefreshFromLayers()
        {
            if (Layers is null) return;

            var flattened = Layers.Flatten();
            Image.Bitmap = flattened; // disposes the previous flattened bitmap, see ImageContext.Bitmap's setter
            Image.BitmapImage = flattened.ToBitmapSource();
        }

        /// <summary>
        /// Gets the history manager.
        /// </summary>
        /// <value>
        /// The history manager.
        /// </value>
        public ImageHistoryManager HistoryManager { get; }

        /// <summary>
        /// Serializes every bitmap edit - canvas tools and whole-image menu
        /// commands alike - so they apply strictly one at a time, each against
        /// its own private copy of the image. See <see cref="ImageEditQueue"/>'s
        /// remarks for the race this replaces (a bare lock plus a fire-and-forget
        /// commit, which still let two edits touch the same live bitmap at once).
        /// </summary>
        /// <value>
        /// The edit queue.
        /// </value>
        public ImageEditQueue EditQueue { get; }

        /// <summary>
        /// Global Key Bindings.
        /// </summary>
        /// <value>
        /// The command bindings.
        /// </value>
        public Dictionary<Tuple<ModifierKeys, Key>, ICommand>? CommandBindings { get; set; }

        // --- 2. UI BINDING PROPERTIES (Proxies to Contexts) ---

        /// <summary>
        /// Incremented every time a new image load starts (thumbnail click, Open,
        /// navigation, ...). Lets a load that's still decoding when a newer one
        /// starts recognise it's stale and drop its result instead of overwriting
        /// whatever the user actually clicked on last. See <see cref="GenerateImageAsync"/>.
        /// </summary>
        private long _imageLoadGeneration;

        /// <summary>
        /// Controls the actual interaction mode of the ImageZoom control (Pan, Rect, FreeForm).
        /// This is updated automatically when MyDrawingState changes.
        /// </summary>
        private ImageZoomTools _imageZoomTool;

        /// <summary>
        /// Gets or sets the image zoom tool.
        /// </summary>
        /// <value>
        /// The image zoom tool.
        /// </value>
        public ImageZoomTools ImageZoomTool
        {
            get => _imageZoomTool;
            set => SetProperty(ref _imageZoomTool, value);
        }

        // --- File Context Proxies ---

        /// <summary>
        /// Gets or sets the count.
        /// </summary>
        /// <value>
        /// The count.
        /// </value>
        public int Count
        {
            get => FileContext.Count;
            set
            {
                if (FileContext.Count == value) return;

                FileContext.Count = value;
                OnPropertyChanged();
                NavigationLogic();
            }
        }

        // --- UI State Proxies ---

        /// <summary>
        /// Gets or sets the left button visibility.
        /// </summary>
        /// <value>
        /// The left button visibility.
        /// </value>
        public Visibility LeftButtonVisibility
        {
            get => UiState.LeftButtonVisibility;
            set
            {
                UiState.LeftButtonVisibility = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets the right button visibility.
        /// </summary>
        /// <value>
        /// The right button visibility.
        /// </value>
        public Visibility RightButtonVisibility
        {
            get => UiState.RightButtonVisibility;
            set
            {
                UiState.RightButtonVisibility = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets the thumbnail visibility.
        /// </summary>
        /// <value>
        /// The thumbnail visibility.
        /// </value>
        public Visibility ThumbnailVisibility
        {
            get => UiState.ThumbnailVisibility;
            set
            {
                UiState.ThumbnailVisibility = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [use sub folders].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [use sub folders]; otherwise, <c>false</c>.
        /// </value>
        public bool UseSubFolders
        {
            get => UiState.UseSubFolders;
            set
            {
                UiState.UseSubFolders = value;
                OnPropertyChanged();
                SlimViewerRegister.MainSubFolders = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [automatic clean].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [automatic clean]; otherwise, <c>false</c>.
        /// </value>
        public bool AutoClean
        {
            get => UiState.AutoClean;
            init
            {
                UiState.AutoClean = value;
                OnPropertyChanged();
                SlimViewerRegister.MainAutoClean = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is thumbs visible.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is thumbs visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsThumbsVisible
        {
            get => UiState.IsThumbsVisible;
            set
            {
                UiState.IsThumbsVisible = value;
                OnPropertyChanged();
                NavigationLogic();
            }
        }

        // --- Transient / Command Properties ---

        /// <summary>
        /// The similarity
        /// </summary>
        private readonly int _similarity;

        /// <summary>
        /// Gets or sets the similarity.
        /// </summary>
        /// <value>
        /// The similarity.
        /// </value>
        public int Similarity
        {
            get => _similarity;
            init
            {
                if (value is < 0 or > 100) return;

                SetProperty(ref _similarity, value);
                Image.Similarity = value;
                SlimViewerRegister.MainSimilarity = value;
            }
        }

        /// <summary>
        /// Undoes this instance.
        /// </summary>
        public async Task UndoAsync()
        {
            if (Layers is not null)
            {
                Layers.Undo();
                RefreshFromLayers();
                return;
            }

            await HistoryManager.UndoAsync();
        }

        /// <summary>
        /// Redoes this instance.
        /// </summary>
        public async Task RedoAsync()
        {
            if (Layers is not null)
            {
                Layers.Redo();
                RefreshFromLayers();
                return;
            }

            await HistoryManager.RedoAsync();
        }

        /// <summary>
        /// Clears the history.
        /// </summary>
        public void ClearHistory() => HistoryManager.ClearHistory();

        // --- 3. INITIALIZATION ---

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageView"/> class.
        /// </summary>
        public ImageView()
        {
            void ReportImageError(Exception ex) =>
                DialogHandler.ErrorDialog(ex.ToString(), nameof(ImageEditQueue));

            HistoryManager = new ImageHistoryManager(Image, onError: ReportImageError);
            EditQueue = new ImageEditQueue(HistoryManager, Image, ReportImageError);
            Commands = new ImageViewCommands(this);
            Initialize();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageView"/> class.
        /// </summary>
        /// <param name="subFolders">if set to <c>true</c> [sub folders].</param>
        /// <param name="compressCif">if set to <c>true</c> [compress cif].</param>
        /// <param name="similarity">The similarity.</param>
        /// <param name="autoClean">if set to <c>true</c> [automatic clean].</param>
        /// <param name="imageZoom">The image zoom.</param>
        /// <param name="mainWindow">The main window.</param>
        /// <param name="thumb">The thumb.</param>
        /// <param name="colorPick">The color pick.</param>
        public ImageView(bool subFolders, bool compressCif, int similarity, bool autoClean,
            ImageZoom? imageZoom, Window? mainWindow, Thumbnails? thumb, ColorPickerMenu? colorPick) : this()
        {
            UseSubFolders = subFolders;
            Image.CompressCif = compressCif;
            Similarity = similarity;
            AutoClean = autoClean;

            // Assign Controls to State (No DataBinding possible for raw Controls)
            UiState.ImageZoomControl = imageZoom;
            UiState.Main = mainWindow;
            UiState.Thumb = thumb;
            UiState.Picker = colorPick;

            Initialize();
        }

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        private void Initialize()
        {
            Image.CustomImageFormat = new CustomImageFormat();

            // Set Initial UI State
            LeftButtonVisibility = RightButtonVisibility = Visibility.Hidden;
            ThumbnailVisibility = Visibility.Visible;

            // CRITICAL: Subscribe to the DrawingState.
            // When user clicks the Toolbar, we map that state to the View behavior.
            MyDrawingState.ToolOrModeChanged += (s, e) => MapStateToZoomTool();

            CommandBindings = new Dictionary<Tuple<ModifierKeys, Key>, ICommand>
            {
                // Modified keys for file operations
                { Tuple.Create(ModifierKeys.Control, Key.O), Commands.Open },
                { Tuple.Create(ModifierKeys.Control, Key.S), Commands.Save },
                { Tuple.Create(ModifierKeys.Control, Key.C), Commands.Clipboard },

                // Add Undo and Redo hotkeys
                { Tuple.Create(ModifierKeys.Control, Key.Z), Commands.Undo },
                { Tuple.Create(ModifierKeys.Control, Key.Y), Commands.Redo },

                // Single keys for fast viewer navigation (ModifierKeys.None)
                { Tuple.Create(ModifierKeys.None, Key.Delete), Commands.Delete },
                { Tuple.Create(ModifierKeys.None, Key.F5), Commands.Refresh },
                { Tuple.Create(ModifierKeys.None, Key.Left), Commands.Previous },
                { Tuple.Create(ModifierKeys.None, Key.Right), Commands.Next },
                { Tuple.Create(ModifierKeys.None, Key.F1), Commands.ShowHelp },
            };
        }

        // --- 4. LOGIC: MAPPING STATE TO BEHAVIOR ---

        /// <summary>
        /// Maps the abstract DrawingState (Pencil, Shape, Mode) to the concrete Tool
        /// required by the ImageZoom control (FreeForm, Rectangle, Move).
        /// </summary>
        private void MapStateToZoomTool()
        {
            ImageZoomTool = MyDrawingState.ActiveTool switch
            {
                DrawTool.Pencil or DrawTool.Eraser or DrawTool.ColorPicker => ImageZoomTools.Dot,
                DrawTool.Shape => MyDrawingState.SelectedShape switch
                {
                    ShapeType.Rectangle => ImageZoomTools.Rectangle,
                    ShapeType.Ellipse => ImageZoomTools.Ellipse,
                    ShapeType.Freeform => ImageZoomTools.FreeForm,
                    ShapeType.Polygon => ImageZoomTools.Polygon,
                    _ => ImageZoomTools.Move
                },
                DrawTool.Move => ImageZoomTools.Move,
                _ => ImageZoomTools.Move
            };
        }

        /// <summary>
        /// Last point of the previous pencil/eraser batch of the current stroke; null between strokes.
        /// </summary>
        private System.Drawing.Point? _lastStrokePoint;

        /// <summary>
        /// Action triggered when a Dot-tool gesture (pencil/eraser drag, or a color-pick
        /// click) has one or more points ready to apply.
        /// </summary>
        /// <param name="wPoints">
        /// The points to apply, in order. For pencil/eraser this is typically more than
        /// one - <see cref="Common.Images.ImageZoom"/> batches everything a drag
        /// accumulated since its last flush, rather than calling this once per mouse-move
        /// sample. See <see cref="Common.Images.ImageZoom.FlushStroke"/>'s remarks for why:
        /// submitting (and therefore cloning/committing) once per point is what made a
        /// drag feel sluggish rather than like a continuous stroke.
        /// </param>
        internal async Task SelectedPointAction(IReadOnlyList<Point> wPoints)
        {
            if (Image.Bitmap == null || wPoints.Count == 0) return;

            // 1. Pencil & Eraser Logic
            if (MyDrawingState.ActiveTool is DrawTool.Pencil or DrawTool.Eraser)
            {
                // Grab UI variables before leaving the main thread
                var isEraser = MyDrawingState.ActiveTool == DrawTool.Eraser;

                // If it's the eraser, use Transparent. Otherwise, use the selected BrushColor.
                var color = isEraser ? Color.Transparent : ColorTranslator.FromHtml(MyDrawingState.BrushColor);
                var size = (int)MyDrawingState.BrushSize;

                var points = new System.Drawing.Point[wPoints.Count];
                for (var i = 0; i < wPoints.Count; i++)
                {
                    points[i] = new System.Drawing.Point((int)wPoints[i].X, (int)wPoints[i].Y);
                }

                // Where in the drag are we? Handlers that get a plain list (no StrokeBatch) treat
                // every call as its own one-batch stroke, i.e. the old behaviour.
                var stroke = wPoints as StrokeBatch;
                var isFirst = stroke?.IsFirst ?? true;
                var isLast = stroke?.IsLast ?? true;

                // Connect this batch to the previous one so batch boundaries don't leave gaps.
                var previous = isFirst ? null : _lastStrokePoint;
                _lastStrokePoint = isLast ? null : points[^1];

                // The queue clones the current bitmap once, hands the clone to
                // this function, and commits whatever it returns - all as one
                // uninterruptible step. Every point in the batch is stamped onto
                // that SAME clone, so a whole drag's worth of dabs costs one
                // clone/commit, not one per dab. Awaiting keeps the command
                // disabled until that has actually finished, so the next batch
                // can't start before this one has landed.
                if (Layers is not null)
                {
                    // Layered document open: draw straight onto the active raster layer (a no-op if the
                    // active layer is a shape layer) instead of the single EditQueue-managed bitmap below.
                    await Layers.DrawStrokeAsync(points, previous, color, size, isFirst, isLast).ConfigureAwait(true);
                    RefreshFromLayers();
                }
                else
                {
                    // The stroke is drawn in place on the queue's private clone (one LockBits, no per-dab
                    // image copies), and only the first batch of a stroke pushes an undo state - so a
                    // whole drag is ONE undo step instead of one per flush.
                    await EditQueue.SubmitAsync(
                        bitmap => ImageProcessor.DrawStroke(bitmap, points, previous, color, size),
                        recordUndo: isFirst);
                }
            }
            // 2. Color Picker (Eyedropper) Logic
            else if (MyDrawingState.ActiveTool == DrawTool.ColorPicker)
            {
                var lastPoint = wPoints[^1];
                var point = new System.Drawing.Point((int)lastPoint.X, (int)lastPoint.Y);
                var pickedHsv = ImageProcessor.GetPixel(Image.Bitmap, point, radius: 1);
                var pickedColor = Color.FromArgb(pickedHsv.A, pickedHsv.R, pickedHsv.G, pickedHsv.B);
                //tell our UI which color we picked
                UiState.Picker?.SetColors(pickedHsv.R, pickedHsv.G, pickedHsv.B, pickedHsv.A);
                MyDrawingState.BrushColor = ColorTranslator.ToHtml(pickedColor);
            }
        }

        /// <summary>
        /// Action triggered when a Shape/Frame selection is completed.
        /// Applies the current Mode (Fill, Texture, Filter) to the area.
        /// </summary>
        /// <param name="frame">The frame.</param>
        internal async Task SelectedFrameAction(SelectionFrame frame)
        {
            if (Image.Bitmap == null) return;

            // Grab UI state variables BEFORE backgrounding to avoid cross-thread exceptions
            var tool = MyDrawingState.ActiveTool;
            var mode = MyDrawingState.ActiveAreaMode;
            var fillColor = MyDrawingState.Fill.Color;
            var texName = MyDrawingState.Texture.TextureName;
            var filterName = MyDrawingState.Filter.FilterName;
            var filled = MyDrawingState.ShapeFilled;

            if (Layers is not null && tool == DrawTool.Shape &&
                Layers.ActiveLayerId is { } activeId && Layers.Document.FindLayer(activeId) is ShapeLayer)
            {
                // A shape layer is active: keep the geometry as data (see Imaging.Objects.Shapes.Shape)
                // instead of baking it into pixels, so it stays movable/restylable and is only rasterized
                // when the document is flattened for display or export.
                var shape = BuildShapeFromFrame(frame, mode, fillColor, texName, filterName, filled);
                if (shape is null) return;

                Layers.AddShape(shape);
                RefreshFromLayers();
                return;
            }

            if (Layers is not null)
            {
                // Layered document open but the active layer is raster (or this is the eraser/erase-mode,
                // which always acts on pixels): run the same fill/texture/filter/erase op the single-image
                // path below uses, against just the active layer, as one undo step.
                await Task.Run(() =>
                {
                    try
                    {
                        Layers.ApplyToActiveRasterLayer(
                            bitmap => ApplyFrameEdit(bitmap, frame, tool, mode, fillColor, texName, filterName),
                            DescribeFrameEdit(tool, mode));
                    }
                    catch (InvalidOperationException)
                    {
                        // Active layer is a shape layer and the tool wasn't Shape (e.g. Eraser while a shape
                        // layer is selected): nothing sensible to do, same as the previous single-image
                        // behavior for an unrecognized combination.
                    }
                }).ConfigureAwait(true);

                RefreshFromLayers();
                return;
            }

            // The function below runs against the queue's own private clone, not
            // Image.Bitmap directly - see ImageEditQueue's remarks for why that
            // matters. Awaiting SubmitAsync (rather than the old fire-and-forget
            // commit) is what keeps the command disabled until this edit has
            // actually landed, so a second selection can't start racing it.
            await EditQueue.SubmitAsync(bitmap =>
                ApplyFrameEdit(bitmap, frame, tool, mode, fillColor, texName, filterName));
        }

        /// <summary>
        /// The single-bitmap fill/texture/filter/erase logic <see cref="SelectedFrameAction"/> used to inline;
        /// factored out so the layered path above can run the exact same edit against just the active layer.
        /// </summary>
        private static Bitmap? ApplyFrameEdit(Bitmap bitmap, SelectionFrame frame, DrawTool tool, AreaMode mode,
            string fillColor, string? texName, string? filterName)
        {
            if (tool == DrawTool.Eraser)
            {
                return ImageProcessor.EraseImage(frame, bitmap);
            }

            if (tool != DrawTool.Shape)
            {
                return null;
            }

            return mode switch
            {
                AreaMode.Fill => ImageProcessor.FillArea(bitmap, frame, ColorTranslator.FromHtml(fillColor)),

                AreaMode.Texture when Enum.TryParse(texName, true, out TextureType texEnum) =>
                    ImageProcessor.FillTexture(bitmap, frame, texEnum),

                AreaMode.Filter when Enum.TryParse(filterName, true, out FiltersType filterEnum) =>
                    ImageProcessor.FillFilter(bitmap, frame, filterEnum),

                AreaMode.Erase => ImageProcessor.EraseImage(frame, bitmap),

                // Texture/Filter with an unrecognized name: leave the image
                // untouched, same as the previous behavior.
                _ => null
            };
        }

        private static string DescribeFrameEdit(DrawTool tool, AreaMode mode) =>
            tool == DrawTool.Eraser
                ? "Erase"
                : mode switch
                {
                    AreaMode.Fill => "Fill",
                    AreaMode.Texture => "Texture",
                    AreaMode.Filter => "Filter",
                    AreaMode.Erase => "Erase",
                    _ => "Edit layer"
                };

        /// <summary>
        /// Turns a completed shape gesture into an <see cref="Shape" /> record for the active shape layer.
        /// Mirrors <see cref="ApplyFrameEdit" />'s mode handling, but produces data instead of pixels. Returns
        /// null for a gesture that has no shape-layer equivalent (currently: FreeForm, which stays a
        /// destructive-only tool since a hand-drawn stroke isn't one of the closed shape kinds).
        /// </summary>
        /// <param name="frame">The frame.</param>
        /// <param name="mode">The mode.</param>
        /// <param name="fillColor">Color of the fill.</param>
        /// <param name="texName">Name of the tex.</param>
        /// <param name="filterName">Name of the filter.</param>
        /// <param name="filled">Whether the shape's interior should be filled at all - see <see cref="DrawingState.ShapeFilled" />.
        /// When <c>false</c>, <paramref name="mode" />/<paramref name="fillColor" />/<paramref name="texName" />/
        /// <paramref name="filterName" /> are ignored and the shape is stroke-only, same as the open shapes
        /// (Trace/Polyline) always are.</param>
        /// <returns></returns>
        private static Shape? BuildShapeFromFrame(SelectionFrame frame, AreaMode mode, string fillColor,
            string? texName, string? filterName, bool filled)
        {
            var fill = filled ? BuildFillFromMode(mode, fillColor, texName, filterName) : FillSpec.None;
            var stroke = new StrokeSpec(unchecked((uint)ColorTranslator.FromHtml(fillColor).ToArgb()), 1.0);

            switch (frame.Tool)
            {
                case ImageZoomTools.Rectangle:
                    return new RectShape(frame.X, frame.Y, frame.Width, frame.Height) { Fill = fill, Stroke = stroke };

                case ImageZoomTools.Ellipse:
                    return new EllipseShape(frame.X, frame.Y, frame.Width, frame.Height)
                        { Fill = fill, Stroke = stroke };

                case ImageZoomTools.Polygon when frame.Points is { Count: >= 3 }:
                    return new PolygonShape(frame.Points.Select(p => new PointD(p.X, p.Y)).ToImmutableArray())
                        { Fill = fill, Stroke = stroke };

                case ImageZoomTools.Trace when frame.Points is { Count: >= 2 }:
                    return new PolylineShape(frame.Points.Select(p => new PointD(p.X, p.Y)).ToImmutableArray())
                        { Stroke = stroke };

                default:
                    return null;
            }
        }

        /// <summary>
        /// Builds the fill from mode.
        /// </summary>
        /// <param name="mode">The mode.</param>
        /// <param name="fillColor">Color of the fill.</param>
        /// <param name="texName">Name of the tex.</param>
        /// <param name="filterName">Name of the filter.</param>
        /// <returns>The fill specification.</returns>
        private static FillSpec BuildFillFromMode(AreaMode mode, string fillColor, string? texName, string? filterName) =>
            mode switch
            {
                AreaMode.Fill => new SolidFill(unchecked((uint)ColorTranslator.FromHtml(fillColor).ToArgb())),
                AreaMode.Texture when !string.IsNullOrWhiteSpace(texName) => new TextureFill(texName),
                AreaMode.Filter when !string.IsNullOrWhiteSpace(filterName) => new FilterFill(filterName),
                _ => FillSpec.None
            };

        /// <summary>
        /// Syncs the Color Picker selection back to the Drawing State.
        /// </summary>
        /// <param name="colorHsv">The color HSV.</param>
        internal void ColorChangedAction(ColorHsv colorHsv)
        {
            // Update state
            MyDrawingState.BrushColor = colorHsv.Hex;

            // If Fill mode is active, sync the fill color too
            if (MyDrawingState.ActiveAreaMode == AreaMode.Fill)
            {
                MyDrawingState.Fill.Color = colorHsv.Hex;
            }
        }

        // --- 5. FILE NAVIGATION & LOADING LOGIC ---

        /// <summary>
        /// Determines whether this instance can run the specified argument.
        /// </summary>
        /// <param name="arg">The argument.</param>
        /// <returns>
        ///   <c>true</c> if this instance can run the specified argument; otherwise, <c>false</c>.
        /// </returns>
        public bool CanRun(object? arg) => CanExecute(arg!);

        // Navigation Actions
        /// <summary>
        /// The thumb filter text
        /// </summary>
        private string? _thumbFilterText;

        /// <summary>
        /// Gets or sets the live, Explorer-style quick-filter applied to the thumbnail strip -
        /// matches by file name, case-insensitive. Setting this just toggles visibility on
        /// already-rendered thumbnails (see Thumbnails.ApplyFilter) rather than reloading anything,
        /// so it's cheap on every keystroke even for a large folder. Cleared automatically whenever
        /// a new folder is loaded (see GenerateThumbView).
        /// </summary>
        /// <value>
        /// The thumb filter text.
        /// </value>
        public string? ThumbFilterText
        {
            get => _thumbFilterText;
            set
            {
                if (_thumbFilterText == value) return;

                _thumbFilterText = value;
                OnPropertyChanged();
                ApplyThumbFilter();
            }
        }

        /// <summary>
        /// Gets a value indicating whether a filter is active and it hid every thumbnail (i.e. no
        /// file name matched). Bound to a small "No matches" placeholder in the UI so a filter that
        /// matches nothing doesn't just look like an empty/broken thumbnail strip.
        /// </summary>
        /// <value>
        ///   <c>true</c> if the current filter matches nothing; otherwise, <c>false</c>.
        /// </value>
        public bool ThumbFilterHasNoMatches =>
            !string.IsNullOrWhiteSpace(_thumbFilterText) &&
            (UiState.Thumb?.GetVisibleIds().Count ?? 0) == 0 &&
            (FileContext.Observer?.Count ?? 0) > 0;

        /// <summary>
        /// Re-applies <see cref="ThumbFilterText" /> to the thumbnail strip.
        /// </summary>
        private void ApplyThumbFilter()
        {
            if (UiState.Thumb == null) return;

            if (string.IsNullOrWhiteSpace(_thumbFilterText))
            {
                UiState.Thumb.ApplyFilter(null);
            }
            else
            {
                var term = _thumbFilterText.Trim();
                UiState.Thumb.ApplyFilter(path =>
                    Path.GetFileName(path).Contains(term, StringComparison.OrdinalIgnoreCase));
            }

            OnPropertyChanged(nameof(ThumbFilterHasNoMatches));
        }

        /// <summary>
        /// Gets the ids Next/Previous should step through: the currently-visible (filtered) ids
        /// when a filter is active and actually matches something, otherwise every id - so arrow
        /// key/button navigation never lands on a thumbnail the filter is hiding.
        /// </summary>
        private List<int>? GetNavigableKeys()
        {
            if (!string.IsNullOrWhiteSpace(_thumbFilterText) && UiState.Thumb is { })
            {
                var visible = UiState.Thumb.GetVisibleIds();
                if (visible is { Count: > 0 }) return visible;
            }

            return FileContext.Observer?.Keys.ToList();
        }

        /// <summary>
        /// Toggles the cif editor action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ToggleCifEditorAction(object obj)
        {
            if (UiState.CifEditorVisibility == Visibility.Visible)
            {
                // Close panel and wipe the active CIF to save memory
                UiState.CifEditorVisibility = Visibility.Collapsed;
                Image.ActiveCif = null;
            }
            else
            {
                // Open panel and close others
                UiState.CifEditorVisibility = Visibility.Visible;
                UiState.FilterConfigVisibility = Visibility.Collapsed;
                UiState.TextureConfigVisibility = Visibility.Collapsed;
                UiState.LayersVisibility = Visibility.Collapsed;

                // If an image is already loaded, convert it immediately
                if (Image.Bitmap is { })
                {
                    Image.ActiveCif = new Cif(Image.Bitmap, Image.CustomImageFormat);
                }
            }
        }

        /// <summary>
        /// Toggles the Layers panel (Advanced Edit Mode's layer stack sidebar), closing the other sidebar
        /// tools the same way <see cref="ToggleCifEditorAction"/>/<see cref="ToggleFilterConfigAction"/>/
        /// <see cref="ToggleTextureConfigAction"/> close each other - only one sidebar tool occupies
        /// SidebarContainer at a time (see MainWindow.xaml).
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ToggleLayersPanelAction(object obj)
        {
            if (UiState.LayersVisibility == Visibility.Visible)
            {
                UiState.LayersVisibility = Visibility.Collapsed;
            }
            else
            {
                UiState.LayersVisibility = Visibility.Visible;
                UiState.FilterConfigVisibility = Visibility.Collapsed;
                UiState.TextureConfigVisibility = Visibility.Collapsed;

                if (UiState.CifEditorVisibility == Visibility.Visible)
                {
                    UiState.CifEditorVisibility = Visibility.Collapsed;
                    Image.ActiveCif = null;
                }
            }
        }

        /// <summary>
        /// Toggles the filter configuration.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ToggleFilterConfigAction(object obj)
        {
            if (UiState.FilterConfigVisibility != Visibility.Visible)
            {
                UiState.FilterConfigVisibility = Visibility.Visible;
                UiState.TextureConfigVisibility = Visibility.Collapsed;
                UiState.LayersVisibility = Visibility.Collapsed;

                if (UiState.CifEditorVisibility == Visibility.Visible)
                {
                    UiState.CifEditorVisibility = Visibility.Collapsed;
                    Image.ActiveCif = null; // Ensure memory is cleared
                }
            }
            else
            {
                UiState.FilterConfigVisibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Toggles the texture configuration action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ToggleTextureConfigAction(object obj)
        {
            if (UiState.TextureConfigVisibility != Visibility.Visible)
            {
                UiState.TextureConfigVisibility = Visibility.Visible;
                UiState.FilterConfigVisibility = Visibility.Collapsed;
                UiState.LayersVisibility = Visibility.Collapsed;

                if (UiState.CifEditorVisibility == Visibility.Visible)
                {
                    UiState.CifEditorVisibility = Visibility.Collapsed;
                    Image.ActiveCif = null; // Ensure memory is cleared
                }
            }
            else
            {
                UiState.TextureConfigVisibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Next Image action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void NextAction(object obj)
        {
            if (FileContext.Observer?.Any() != true) return;

            ChangeImage(Utility.GetNextElement(FileContext.CurrentId, GetNavigableKeys()));
            // Drive the thumbnail highlight/scroll from FileContext.CurrentId (now updated by ChangeImage)
            // instead of Thumbnails' own internal click-tracked state, so it can never drift out of sync.
            UiState.Thumb?.SelectAndCenter(FileContext.CurrentId);
            NavigationLogic();
        }

        /// <summary>
        /// Previous Image action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void PreviousAction(object obj)
        {
            if (FileContext.Observer == null || FileContext.Observer.Count == 0) return;

            ChangeImage(Utility.GetPreviousElement(FileContext.CurrentId, GetNavigableKeys()));
            // See NextAction: keep the thumbnail highlight/scroll anchored to the real current id.
            UiState.Thumb?.SelectAndCenter(FileContext.CurrentId);
            NavigationLogic();
        }

        /// <summary>
        /// Window Actions.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void CloseAction(object obj)
        {
            // 1. Update the register with the CURRENT state of the UI/ViewModel
            SlimViewerRegister.MainSubFolders = UseSubFolders;
            SlimViewerRegister.MainCompressCif = Image.CompressCif;
            SlimViewerRegister.MainSimilarity = Similarity;
            SlimViewerRegister.MainAutoClean = AutoClean;

            if (UiState.ImageZoomControl is { })
                SlimViewerRegister.MainAutoPlayGif = UiState.ImageZoomControl.AutoplayGifImage;

            // 2. Extract the updated Config object from the Register
            var config = SlimViewerRegister.GetRegister();

            // 3. Save it to disk
            Config.SetConfig(config);

            if (AutoClean)
            {
                var fileCmd = new FileProcessingCommands();
                fileCmd.CleanTempFolder(true);
            }

            Application.Current.Shutdown();
        }

        /// <summary>
        /// Refreshes the action.
        /// </summary>
        /// <param name="caller">The caller.</param>
        internal async Task RefreshActionAsync(string caller)
        {
            Trace.WriteLine($"Caller: {caller}"); // Slightly cleaner using string interpolation
            // 1. Reset state via FileContext (triggers OnPropertyChanged for Observer)
            FileContext.Clear();

            // 2. Reset local UI-only state
            Image.Clear();
            ClearHistory();

            // 3. Reload if directory exists
            if (Directory.Exists(FileContext.CurrentPath))
            {
                // LoadThumbs calls GenerateThumbView, which updates FileContext.Observer
                await LoadThumbs(FileContext.CurrentPath);
            }

            // 4. Update button states
            NavigationLogic();
        }

        /// <summary>
        /// Clears the action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ClearAction(object obj)
        {
            if (FileContext.Observer?.ContainsKey(FileContext.CurrentId) == false) return;

            UiState.Thumb?.RemoveSingleItem(FileContext.CurrentId);
            if (Count > 0) Count--;

            Image.Clear();

            ClearHistory();

            NextAction(this);
        }

        /// <summary>
        /// File Dialog Actions. These use the DialogHandler service to get file paths, then call the appropriate loading and thumbnail generation methods.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void OpenAction(object obj)
        {
            var pathObj = DialogHandler.HandleFileOpen(ViewResources.FileOpen, FileContext.CurrentPath);
            if (string.IsNullOrEmpty(pathObj?.FilePath)) return;

            FileContext.CurrentPath = pathObj.Folder;

            if (string.Equals(pathObj.Extension, ViewResources.CbzExt, StringComparison.OrdinalIgnoreCase))
            {
                _ = GenerateCbrViewAsync(pathObj);
                return;
            }

            if (!ImagingResources.Appendix.Contains(pathObj.Extension?.ToLower()))
            {
                _ = MessageBox.Show(ViewResources.ErrorFileNotSupported + pathObj.Extension,
                    ViewResources.ErrorMessage);
                return;
            }

            GenerateView(pathObj.FilePath);

            _ = LoadThumbs(pathObj.Folder, pathObj.FilePath);
        }

        /// <summary>
        /// Opens the CBZ action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void OpenCbzAction(object obj)
        {
            var pathObj = DialogHandler.HandleFileOpen(ViewResources.FileOpenCbz, FileContext.CurrentPath);
            if (pathObj == null || !File.Exists(pathObj.FilePath)) return;

            _ = GenerateCbrViewAsync(pathObj);
        }

        /// <summary>
        /// Generates the atlas action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void GenerateAtlasAction(object obj)
        {
            _ = GenerateTextureAtlasAsync();
        }

        /// <summary>
        /// Opens the cif action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void OpenCifAction(object obj)
        {
            var pathObj = DialogHandler.HandleFileOpen(ViewResources.FileOpenCif, FileContext.CurrentPath);
            if (pathObj == null || !File.Exists(pathObj.FilePath)) return;

            // 1. Update the FileContext path so subsequent calls read the correct new file
            FileContext.FilePath = pathObj.FilePath;

            // 2. Store the raw CIF object in ImageContext
            Image.ActiveCif = Image.CustomImageFormat?.GetCif(FileContext.FilePath);
            if (Image.ActiveCif == null) return;

            // Continue with existing render logic
            ResetLayers();
            Image.Bitmap = Image.CustomImageFormat?.GetImageFromCif(FileContext.FilePath);
            if (Image.Bitmap == null) return;

            Image.BitmapImage = Image.BitmapSource;
            FileContext.FileName = Path.GetFileName(FileContext.FilePath);
            Image.Information =
                ViewResources.BuildImageInformation(FileContext.FilePath, FileContext.FileName, Image.BitmapImage);

            // 3. Update the panel visibility via UiState
            UiState.CifEditorVisibility = Visibility.Visible;
        }

        /// <summary>
        /// Folders the action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void FolderAction(object obj)
        {
            var path = DialogHandler.ShowFolder(FileContext.CurrentPath);
            if (!Directory.Exists(path)) return;

            _ = LoadThumbs(path);
        }

        /// <summary>
        /// Explorers the action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ExplorerAction(object obj)
        {
            if (!Directory.Exists(FileContext.CurrentPath)) return;

            var argument = !File.Exists(FileContext.FilePath)
                ? FileContext.CurrentPath
                : ViewResources.Select + FileContext.FilePath;
            _ = Process.Start(ViewResources.Explorer, argument);
        }

        /// <summary>
        /// Exports the string action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ExportStringAction(object obj)
        {
            if (Image.Bitmap != null) ImageProcessor.ExportString(Image.Bitmap);
        }


        /// <summary>
        /// Exports the clipboard action.
        /// </summary>
        /// <param name="obj">The object.</param>
        internal void ExportClipboardAction(object? obj)
        {
            // 1. Ensure we have an image to copy
            if (Image.BitmapImage is { } bitmap)
            {
                try
                {
                    // 2. Place it on the Windows Clipboard
                    Clipboard.SetImage(bitmap);
                }
                catch (Exception ex)
                {
                    // Clipboard access can occasionally fail if another app locks it
                    Trace.WriteLine($"Clipboard error: {ex.Message}");
                }
            }
        }

        // --- 6. HELPER METHODS (Loading & Thumbnails) ---

        /// <summary>
        /// Changes the image.
        /// </summary>
        /// <param name="id">The identifier.</param>
        public void ChangeImage(int id)
        {
            if (!FileContext.Observer.TryGetValue(id, out var path) || !File.Exists(path))
            {
                _ = RefreshActionAsync(nameof(ChangeImage));
                return;
            }

            // Just pass the path and ID to the core pipeline
            UpdateImageState(targetPath: path, targetId: id);
        }

        /// <summary>
        /// Changes the image.
        /// </summary>
        /// <param name="files">The files.</param>
        public void ChangeImage(IEnumerable<string?> files)
        {
            UpdateImageState(newFiles: files);
        }

        /// <summary>
        /// Changes the image.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        public void ChangeImage(string? filePath)
        {
            if (!CanLoadFile(filePath)) return;

            UpdateImageState(targetPath: filePath);
        }

        /// <summary>
        /// Reloads the view with a new list of files and a specific target image.
        /// Used by Rename/Convert commands to refresh the state.
        /// </summary>
        /// <param name="files">The files.</param>
        /// <param name="filePath">The file path.</param>
        /// <param name="info">The information.</param>
        internal void ChangeImage(IEnumerable<string?> files, string? filePath, string info)
        {
            if (!CanLoadFile(filePath)) return;

            // Filter out nulls if your files list contains them, or pass as-is if FileContext expects it
            UpdateImageState(targetPath: filePath, newFiles: files.Where(f => f is { }), customInfo: info);
        }

        /// <summary>
        /// Saves the image using the external ImageProcessor.
        /// Called by FileProcessingCommands.Save.
        /// </summary>
        /// <param name="path">The full file path.</param>
        /// <param name="extension">The file extension (e.g., ".png").</param>
        /// <param name="bitmap">The GDI+ Bitmap (System.Drawing.Bitmap).</param>
        /// <returns>True if successful, False otherwise.</returns>
        internal bool SaveImage(string? path, string? extension, Bitmap? bitmap)
        {
            // Update UI Status to "Working" (Red)
            UiState.IsBusy = true;

            // Call the lower-level processor logic
            var success = ImageProcessor.SaveImage(path, extension, bitmap);

            // Update UI Status to "Done" (Green)
            UiState.IsBusy = false;

            return success;
        }

        // Logic Helpers


        /// <summary>
        /// The central pipeline for all image and context changes.
        /// Guarantees state is updated in a strict, predictable order.
        /// </summary>
        /// <param name="targetPath">The target path.</param>
        /// <param name="targetId">The target identifier.</param>
        /// <param name="newFiles">The new files.</param>
        /// <param name="customInfo">The custom information.</param>
        private void UpdateImageState(string? targetPath = null, int? targetId = null,
            IEnumerable<string>? newFiles = null, string? customInfo = null)
        {
            // ==========================================
            // PHASE 1: Update File Context & Thumbnails
            // ==========================================
            if (newFiles is { })
            {
                FileContext.Files = newFiles.ToList();
                Count = FileContext.Files.Count;

                try
                {
                    FileContext.CurrentPath = FileContext.Files.Count != 0
                        ? Path.GetDirectoryName(FileContext.Files[0])
                        : string.Empty;
                }
                catch (ArgumentException ex)
                {
                    Trace.WriteLine(ex);
                    MessageBox.Show(ex.ToString(), ViewResources.ErrorMessage);
                    return; // Halt pipeline on critical error
                }

                _ = GenerateThumbView(FileContext.Files);
            }
            else if (!string.IsNullOrEmpty(targetPath))
            {
                // If we didn't get an explicit list of files, check if the folder changed
                var folder = Path.GetDirectoryName(targetPath);

                if (folder is { } && folder != FileContext.CurrentPath)
                {
                    // If you are in "SubFolder" mode, don't reload if the new folder
                    // is just a child of the current path.
                    var isSubfolder = FileContext.CurrentPath != null &&
                                      folder.StartsWith(FileContext.CurrentPath, StringComparison.OrdinalIgnoreCase);

                    if (!UiState.UseSubFolders || !isSubfolder)
                    {
                        _ = LoadThumbs(folder, targetPath);
                    }
                }
            }

            // ==========================================
            // PHASE 2: Load Target Image & Metadata
            // ==========================================
            if (!string.IsNullOrEmpty(targetPath))
            {
                // A specific image was requested
                FileContext.CurrentId = targetId ?? FileContext.CurrentIdGetIdByFilePath(targetPath);
                _ = GenerateImageAsync(targetPath);

                // If no custom info was provided, let GenerateImageAsync handle it (or set a default)
                if (!string.IsNullOrEmpty(customInfo)) Image.Information = customInfo;
            }
            else
            {
                // No image requested (e.g., just loaded a fresh folder) -> Clear image state
                FileContext.CurrentId = -1;
                Image.Clear();

                Image.Information = customInfo ?? string.Concat(ViewResources.DisplayImages, Count);
            }

            // ==========================================
            // PHASE 3: Finalize UI
            // ==========================================
            NavigationLogic();
        }


        /// <summary>
        /// Determines whether this instance [can load file] the specified path.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>
        ///   <c>true</c> if this instance [can load file] the specified path; otherwise, <c>false</c>.
        /// </returns>
        private bool CanLoadFile(string? path) => !string.IsNullOrEmpty(path) && File.Exists(path) &&
                                                  ImagingResources.Appendix.Any(path.EndsWith);

        /// <summary>
        /// Generates the view.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        internal async void GenerateView(string? filePath)
        {
            //we always check before we load so the path must exist
            var info = FileHandleSearch.GetFileDetails(filePath!);

            if (info == null)
            {
                Image.Clear();
                await LoadThumbs(FileContext.CurrentPath);
                return;
            }

            await GenerateImageAsync(filePath);
        }

        /// <summary>
        /// Generates the image asynchronous.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        private async Task GenerateImageAsync(string? filePath)
        {
            if (!File.Exists(filePath))
            {
                Trace.WriteLine($"File not found: {filePath}");
                return;
            }

            // Tag this call so a slower, older click can't clobber a newer one, and
            // so the busy indicator only clears once the *latest* click is actually
            // done - see the two checks against _imageLoadGeneration below.
            var myGeneration = Interlocked.Increment(ref _imageLoadGeneration);
            UiState.IsBusy = true;

            try
            {
                var ext = Path.GetExtension(filePath);
                if (ext.Equals(ImagingResources.GifExt, StringComparison.OrdinalIgnoreCase))
                {
                    if (Image.GifPath?.Equals(filePath, StringComparison.OrdinalIgnoreCase) == true) return;

                    // important for the undo/redo logic
                    ClearHistory();

                    Image.BitmapImage = null; // Clear any residual static image
                    Image.GifPath = filePath;
                    var info = ImageGifHandler.GetImageInfo(filePath);
                    Image.Information = ViewResources.BuildGifInformation(filePath, info);
                }
                else
                {
                    // Load static image
                    var bmp = await Task.Run(() => ImageProcessor.Render.GetOriginalBitmap(filePath));

                    // Another thumbnail was clicked while this one was still decoding.
                    // That newer call already owns the display now - drop this result
                    // (and the bitmap it decoded) instead of overwriting it.
                    if (myGeneration != Interlocked.Read(ref _imageLoadGeneration))
                    {
                        bmp?.Dispose();
                        return;
                    }

                    // IMPORTANT: clear GifPath *before* pushing the new BitmapImage.
                    // ImageZoom.ImagePath and ImageZoom.ImageSource are two separate
                    // dependency properties bound to Image.GifPath / Image.BitmapImage
                    // respectively, and each has its own independent change handler:
                    //   - ImagePath changing to null/empty nulls out BtmImage.Source.
                    //   - ImageSource changing pushes the new bitmap into BtmImage.Source.
                    // Setting GifPath = null *after* BitmapImage was already applied re-triggers
                    // the ImagePath handler and wipes the freshly-set bitmap back to null - the
                    // image would only actually appear after opening a second, different image
                    // (because by then GifPath is already null, so re-assigning null is a no-op
                    // and the handler never fires again). Clearing GifPath first avoids the clobber.
                    ResetLayers();
                    Image.GifPath = null;
                    Image.Bitmap = bmp;
                    Image.BitmapImage = Image.BitmapSource; // Trigger UI update via ImageSource binding

                    if (Image.Bitmap is { } && UiState.CifEditorVisibility == Visibility.Visible)
                    {
                        // Convert to CIF automatically because the panel is open
                        Image.ActiveCif = new Cif(Image.Bitmap, Image.CustomImageFormat);
                    }
                    else
                    {
                        // Ensure memory is cleared if the panel is closed
                        Image.ActiveCif = null;
                    }

                    Image.Information =
                        ViewResources.BuildImageInformation(filePath, FileContext.FileName, Image.BitmapImage);
                }

                FileContext.FilePath = filePath;
                FileContext.FileName = Path.GetFileName(filePath);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex);
                _ = MessageBox.Show(ex.ToString(), ViewResources.ErrorMessage);
            }
            finally
            {
                // Only the most recent click gets to declare "done". If an older,
                // slower call is finishing late, a newer one may already be back in
                // flight - clearing the indicator here would hide that it's still working.
                if (myGeneration == Interlocked.Read(ref _imageLoadGeneration))
                {
                    UiState.IsBusy = false;
                }
            }
        }

        /// <summary>
        /// Loads the thumbs.
        /// </summary>
        /// <param name="folder">The folder.</param>
        /// <param name="filePath">The file path.</param>
        internal async Task LoadThumbs(string? folder, string? filePath = null)
        {
            // Await the folder processing so we don't move to selection too early
            await GenerateThumbView(folder).ConfigureAwait(true);

            if (!string.IsNullOrEmpty(filePath))
                FileContext.CurrentId = FileContext.CurrentIdGetIdByFilePath(filePath);
            else
            {
                FileContext.CurrentId = -1;
                Image.Clear();
            }
        }

        /// <summary>
        /// Generates the thumb view from a folder path.
        /// </summary>
        /// <param name="folder">The folder.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task GenerateThumbView(string? folder)
        {
            FileContext.CurrentPath = folder;
            UiState.IsBusy = true;

            // A filter from the previous folder shouldn't silently persist and hide everything in
            // the new one. Reset the backing field directly (not the property) - there's nothing
            // to un-filter yet since the thumb strip is about to be rebuilt from scratch anyway,
            // this is just here to keep the filter textbox's bound Text visually cleared.
            if (_thumbFilterText is { })
            {
                _thumbFilterText = null;
                OnPropertyChanged(nameof(ThumbFilterText));
            }

            // Both the file-system scan and the natural-sort pass below can take real, noticeable
            // time on a folder with a huge number of images (or a recursive sub-folder scan) - and
            // both used to run synchronously right here on the UI thread, before hitting the first
            // real 'await' further down. That blocks the UI thread solid for the whole scan, so
            // WPF never actually gets a chance to render the just-set IsBusy=true - the indicator
            // was "on" the whole time, it just never got painted. Doing the scan+sort inside
            // Task.Run keeps the UI thread free to actually show it.
            var (files, sortedFiles) = await Task.Run(() =>
            {
                var scanned = FileHandleSearch.GetFilesByExtensionFullPath(
                    folder,
                    ImagingResources.Appendix,
                    UiState.UseSubFolders);

                var sorted = scanned.IsNullOrEmpty() ? null : scanned.PathSort();

                return (scanned, sorted);
            }).ConfigureAwait(true);

            if (files.IsNullOrEmpty())
            {
                Count = 0;
                FileContext.Observer = null;
                Image.Clear();
                // No further work is coming (GenerateThumbView(sortedFiles) below is what
                // normally clears the busy state) - clear it here too, otherwise an empty
                // folder leaves the indicator stuck on "busy" forever.
                UiState.IsBusy = false;
                NavigationLogic(); // Update UI for empty state
                return;
            }

            FileContext.Files = files;
            Count = files.Count;

            // 2. WAIT for the dictionary generation to complete
            // This is the crucial change: 'await' instead of '_'
            await GenerateThumbView(sortedFiles).ConfigureAwait(true);

            // 3. Now that Observer is guaranteed to be set, update the UI
            NavigationLogic();
        }

        /// <summary>
        /// Generates the dictionary and updates the UI source.
        /// </summary>
        /// <param name="lst">The list of images.</param>
        private async Task GenerateThumbView(IReadOnlyCollection<string?>? lst)
        {
            if (!IsThumbsVisible || lst == null)
            {
                // Nothing is actually going to run - don't leave the indicator stuck on "busy"
                // from the outer GenerateThumbView(folder) call that got us here.
                UiState.IsBusy = false;
                return;
            }

            UiState.IsBusy = true;

            // Create the dictionary in the background
            var dict = await Task.Run(lst.ToDictionary).ConfigureAwait(false);

            // Switch back to the UI thread to update the property
            await Application.Current.Dispatcher.InvokeAsync(() =>
            {
                // This triggers FileContext.OnPropertyChanged(nameof(Observer))
                FileContext.Observer = dict;

                UiState.IsBusy = false;
                NavigationLogic();
            });
        }

        /// <summary>
        /// Generates the CBR view.
        /// </summary>
        /// <param name="pathObj">The path object.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task GenerateCbrViewAsync(PathObject? pathObj)
        {
            if (pathObj == null) return;

            UiState.UseSubFolders = true;
            var folder = ImageProcessor.UnpackFolder(pathObj.FilePath, pathObj.FileNameWithoutExt);
            if (!string.IsNullOrEmpty(folder)) FileContext.CurrentPath = folder;
            var file = ImageProcessor.UnpackFile(folder);
            if (file == null) return;

            GenerateView(file);
            await LoadThumbs(folder, file);
        }

        /// <summary>
        /// Generates the texture atlas asynchronous.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task GenerateTextureAtlasAsync()
        {
            if (FileContext.CurrentPath == null) return;

            ImageProcessor.GenerateTextureAtlas(FileContext.CurrentPath);
        }

        /// <summary>
        /// Navigation logic.
        /// </summary>
        internal void NavigationLogic()
        {
            if (FileContext.Count <= 1)
                UiState.HideButtons();
            else
            {
                RightButtonVisibility = FileContext.CurrentId == FileContext.Count - 1
                    ? Visibility.Hidden
                    : Visibility.Visible;
                LeftButtonVisibility = FileContext.CurrentId <= 0 ? Visibility.Hidden : Visibility.Visible;
            }

            ThumbnailVisibility = UiState.ThumbnailState();
        }

        /// <summary>
        /// Images the loaded command action.
        /// </summary>
        /// <param name="obj">The object.</param>
        public void ImageLoadedCommandAction(object obj)
        {
            UiState.IsBusy = false;
        }

        /// <summary>
        /// Thumbs the image clicked action.
        /// </summary>
        /// <param name="obj">The <see cref="ImageEventArgs"/> instance containing the event data.</param>
        internal void ThumbImageClickedAction(ImageEventArgs obj)
        {
            ChangeImage(obj.Id);
        }
    }
}