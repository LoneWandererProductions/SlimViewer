/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViews
 * FILE:        ImageMassProcessingCommands.cs
 * PURPOSE:     Your file purpose here
 * PROGRAMMER:  Peter Geinitz (Wayfarer)
 */

using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Common.Dialogs;
using SlimViews.Interfaces;
using SlimViews.Tooling;

namespace SlimViews
{
    /// <summary>
    /// Handler for all sub Windows related to Mass Image Processing
    /// </summary>
    internal class ImageMassProcessingCommands
    {
        /// <summary>
        /// Keep track of all currently open sub windows
        /// </summary>
        private readonly List<Window> _subWindows = new();

        /// <summary>
        /// Folders the convert window.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void FolderConvertWindow(ImageView owner)
        {
            SlimViewerRegister.ResetConvert();
            _ = InitDialog<Converter>(owner, modal: true);

            if (!SlimViewerRegister.IsPathsSet)
            {
                ImageProcessor.FolderConvert(
                    SlimViewerRegister.Target,
                    SlimViewerRegister.Source,
                    owner.FileContext.Observer);
            }
        }

        /// <summary>
        /// Scales the window.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void ScaleWindow(ImageView owner)
        {
            SlimViewerRegister.ResetScaling();
            _ = InitDialog<Scale>(owner, modal: true);

            owner.Image.Bitmap = ImageProcessor.BitmapScaling(owner.Image.Bitmap, SlimViewerRegister.Scaling);
            owner.Image.Bitmap = ImageProcessor.RotateImage(owner.Image.Bitmap, SlimViewerRegister.Degree);
            owner.Image.Bitmap = ImageProcessor.CropImage(owner.Image.Bitmap);
            owner.Image.BitmapImage = owner.Image.BitmapSource;
        }

        /// <summary>
        /// Rename the Folder action.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void FolderRenameWindow(ImageView? owner)
        {
            //catch someone doesn't try to rename files when no folder is loaded

            if (owner.FileContext.Observer == null)
            {
                DialogHandler.ErrorDialog("No files to rename. Please load a folder first.", "Rename Error");
                return;
            }

            SlimViewerRegister.ResetRenaming();

            var dct = new Dictionary<int, string>();

            // 1. Build the dictionary (Partial vs Full)
            if (owner.UiState.Thumb.IsSelectionValid)
            {
                foreach (var id in owner.UiState.Thumb.Selection.Keys.Where(id =>
                             owner.FileContext.IsKeyInObserver(id)))
                    dct.Add(id, owner.FileContext.Observer[id]);
            }
            else
            {
                dct = new Dictionary<int, string>(owner.FileContext.Observer);
            }

            // 2. Open the Window
            var rename = new Rename(owner, dct)
            {
                // Note: Topmost = true keeps this above EVERY app in Windows (like your web browser).
                Topmost = true,
                Owner = owner.UiState.Main
            };

            _ = rename.ShowDialog();

            // 3. Merge changes back safely
            if (SlimViewerRegister.Changed)
            {
                // Safely update the backend Dictionary without destroying unselected items
                foreach (var (key, value) in rename.Observer)
                {
                    owner.FileContext.Observer[key] = value;
                }

                // CRITICAL: Force the UI to update by assigning a new dictionary reference
                // to the ViewModel's public property
                owner.FileContext.Observer = new Dictionary<int, string>(owner.FileContext.Observer);

                // Reset the flag
                SlimViewerRegister.ResetRenaming();
            }
        }

        /// <summary>
        /// Opens the duplicate/similar-image search configuration dialog, then launches the
        /// comparison window with whatever folders/mode/percentage the user chose. Replaces the
        /// old DuplicateWindow/SimilarWindow pair (four fixed 70/80/90/95% menu presets, always
        /// scoped to just the currently-open folder) with one entry point that lets the user pick
        /// any folder(s) and an exact percentage.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void FindDuplicatesWindow(ImageView? owner)
        {
            var config = new DuplicateSearchConfig(owner.FileContext.CurrentPath)
            {
                Topmost = true,
                Owner = owner.UiState.Main
            };

            if (config.ShowDialog() != true) return;

            var compareWindow = new Compare(config.IncludeSubfolders, config.Folders.ToList(), owner,
                config.Similarity)
            {
                Topmost = false,
                Owner = owner.UiState.Main
            };

            compareWindow.Show();

            SlimViewerRegister.CompareView = true;
        }

        /// <summary>
        /// Resizers the window.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void ResizerWindow(ImageView owner)
        {
            var resizer = new Resizer(owner.FileContext.CurrentPath)
            {
                Topmost = false,
                Owner = owner.UiState.Main
            };
            resizer.Show();
        }

        /// <summary>
        /// Folders the search.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void FolderSearch(ImageView owner) => InitDialog<Search>(owner);

        /// <summary>
        /// Analyzers the window.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void AnalyzerWindow(ImageView owner) =>
            InitDialog<DetailCompare>(owner);

        /// <summary>
        /// GIFs the window.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="filePath">The file path.</param>
        internal void GifWindow(ImageView owner, string filePath)
        {
            // 1. Manually create the window (Don't use InitDialog yet)
            var gifWindow = new Gif
            {
                Owner = owner.UiState.Main,
                Topmost = false,
                InitialFilePath = filePath // SET THIS BEFORE SHOWING
            };

            // 2. Perform the registration that InitDialog usually does
            _subWindows.Add(gifWindow);
            gifWindow.Closed += (_, __) => _subWindows.Remove(gifWindow);

            if (gifWindow is IClosableByCommand closable)
            {
                closable.RequestCloseAction = () =>
                {
                    if (gifWindow.IsLoaded) gifWindow.Close();
                };
            }

            // 3. NOW show it. Window_Loaded will now see the correct InitialFilePath.
            gifWindow.Show();
        }

        /// <summary>
        /// Shows the help.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void ShowHelp(ImageView owner) => InitDialog<HelpWindow>(owner);

        /// <summary>
        /// Shows the about.
        /// </summary>
        /// <param name="owner">The owner.</param>
        internal void ShowAbout(ImageView owner) => InitDialog<AboutWindow>(owner);


        /// <summary>
        /// Initializes the dialog.
        /// </summary>
        /// <typeparam name="T">Generic Type.</typeparam>
        /// <param name="owner">The owner.</param>
        /// <param name="modal">if set to <c>true</c> [modal].</param>
        /// <returns>Reference to Window</returns>
        private T InitDialog<T>(ImageView owner, bool modal = false) where T : Window, new()
        {
            var window = new T
            {
                Owner = owner.UiState.Main,
                Topmost = true
            };

            // Register in subwindow list
            _subWindows.Add(window);
            window.Closed += (_, __) => _subWindows.Remove(window);

            // Attach callback so the subwindow asks THIS class to close it
            if (window is IClosableByCommand closable)
            {
                closable.RequestCloseAction = () =>
                {
                    // central close
                    if (window.IsLoaded)
                        window.Close();
                };
            }

            if (modal)
                window.ShowDialog();
            else
                window.Show();

            return window;
        }

        /// <summary>
        /// Close all registered subwindows safely.
        /// </summary>
        internal void CloseAllSubWindows()
        {
            foreach (var w in _subWindows.ToList())
            {
                if (w.IsLoaded) w.Close();
            }

            _subWindows.Clear();
        }
    }
}