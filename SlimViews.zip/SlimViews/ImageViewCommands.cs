/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViews
 * FILE:        ImageViewCommands.cs
 * PURPOSE:     Main command definitions and bindings for ImageView, linking UI actions to service methods.
 * PROGRAMMER:  Peter Geinitz (Wayfarer)
 */

using Common.Images;
using Core.MemoryLog;
using Imaging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ViewModel;

namespace SlimViews
{
    /// <summary>
    /// Provides all image view related commands and links them to the owning view and service classes.
    /// This class is responsible for command creation, binding, and routing actions to the appropriate services.
    /// </summary>
    public class ImageViewCommands
    {
        /// <summary>
        /// The owner, unused for command execution but may be needed for CanExecute checks or future command implementations.
        /// </summary>
        private readonly ImageView _owner;

        /// <summary>
        /// The image mass service
        /// </summary>
        private readonly ImageMassProcessingCommands _imageMassService = new();

        /// <summary>
        /// The image service
        /// </summary>
        private readonly ImageProcessingCommands _imageService = new();

        /// <summary>
        /// The file service
        /// </summary>
        internal FileProcessingCommands FileService { get; } = new();

        #region Commands

        /// <summary>
        /// Gets the close Command.
        /// </summary>
        /// <value>
        /// The close Command.
        /// </value>
        public ICommand Close { get; }

        /// <summary>
        /// Gets the open CBZ Command.
        /// </summary>
        /// <value>
        /// The open CBZ Command.
        /// </value>
        public ICommand OpenCbz { get; }

        /// <summary>
        /// Gets or sets the generate atlas.
        /// </summary>
        /// <value>
        /// The generate atlas.
        /// </value>
        public ICommand GenerateAtlas { get; set; }

        /// <summary>
        /// Gets the open.
        /// </summary>
        /// <value>
        /// The open.
        /// </value>
        public ICommand Open { get; }

        /// <summary>
        /// Gets the save.
        /// </summary>
        /// <value>
        /// The save.
        /// </value>
        public ICommand Save { get; }

        /// <summary>
        /// Gets the clipboard.
        /// </summary>
        /// <value>
        /// The clipboard.
        /// </value>
        public ICommand Clipboard { get; }

        /// <summary>
        /// Gets the delete.
        /// </summary>
        /// <value>
        /// The delete.
        /// </value>
        public ICommand Delete { get; }

        /// <summary>
        /// Gets the refresh.
        /// </summary>
        /// <value>
        /// The refresh.
        /// </value>
        public ICommand Refresh { get; }

        /// <summary>
        /// Gets the pixelate.
        /// </summary>
        /// <value>
        /// The pixelate.
        /// </value>
        public ICommand Pixelate { get; }

        /// <summary>
        /// Gets the command that opens the duplicate/similar-image search dialog (folder
        /// selection + exact percentage, replacing the old fixed-preset Duplicate/Similar
        /// command pair).
        /// </summary>
        /// <value>
        /// The find duplicates command.
        /// </value>
        public ICommand FindDuplicates { get; }

        /// <summary>
        /// Gets the rename.
        /// </summary>
        /// <value>
        /// The rename.
        /// </value>
        public ICommand Rename { get; }

        /// <summary>
        /// Gets the folder.
        /// </summary>
        /// <value>
        /// The folder.
        /// </value>
        public ICommand Folder { get; }

        /// <summary>
        /// Gets the mirror.
        /// </summary>
        /// <value>
        /// The mirror.
        /// </value>
        public ICommand Mirror { get; }

        /// <summary>
        /// Gets the rotate forward.
        /// </summary>
        /// <value>
        /// The rotate forward.
        /// </value>
        public ICommand RotateForward { get; }

        /// <summary>
        /// Gets the rotate backward.
        /// </summary>
        /// <value>
        /// The rotate backward.
        /// </value>
        public ICommand RotateBackward { get; }

        /// <summary>
        /// Gets the explorer.
        /// </summary>
        /// <value>
        /// The explorer.
        /// </value>
        public ICommand Explorer { get; }

        /// <summary>
        /// Gets the scale.
        /// </summary>
        /// <value>
        /// The scale.
        /// </value>
        public ICommand Scale { get; }

        /// <summary>
        /// Gets the folder rename.
        /// </summary>
        /// <value>
        /// The folder rename.
        /// </value>
        public ICommand FolderRename { get; }

        /// <summary>
        /// Gets the folder convert.
        /// </summary>
        /// <value>
        /// The folder convert.
        /// </value>
        public ICommand FolderConvert { get; }

        /// <summary>
        /// Gets the clear.
        /// </summary>
        /// <value>
        /// The clear.
        /// </value>
        public ICommand Clear { get; }

        /// <summary>
        /// Gets the clean temporary folder.
        /// </summary>
        /// <value>
        /// The clean temporary folder.
        /// </value>
        public ICommand CleanTempFolder { get; }

        /// <summary>
        /// Gets the folder search.
        /// </summary>
        /// <value>
        /// The folder search.
        /// </value>
        public ICommand FolderSearch { get; }

        /// <summary>
        /// Gets the move.
        /// </summary>
        /// <value>
        /// The move.
        /// </value>
        public ICommand Move { get; }

        /// <summary>
        /// Gets the move all.
        /// </summary>
        /// <value>
        /// The move all.
        /// </value>
        public ICommand MoveAll { get; }

        /// <summary>
        /// Gets the open cif.
        /// </summary>
        /// <value>
        /// The open cif.
        /// </value>
        public ICommand OpenCif { get; }

        /// <summary>
        /// Gets the convert cif.
        /// </summary>
        /// <value>
        /// The convert cif.
        /// </value>
        public ICommand ConvertCif { get; }

        /// <summary>
        /// Gets the toggle cif editor.
        /// </summary>
        /// <value>
        /// The toggle cif editor.
        /// </value>
        public ICommand ToggleCifEditor { get; }

        /// <summary>
        /// Gets the toggle filter configuration.
        /// </summary>
        /// <value>
        /// The toggle filter configuration.
        /// </value>
        public ICommand ToggleFilterConfig { get; }

        /// <summary>
        /// Gets the toggle texture configuration.
        /// </summary>
        /// <value>
        /// The toggle texture configuration.
        /// </value>
        public ICommand ToggleTextureConfig { get; }

        /// <summary>
        /// Gets the toggle layers panel command (the "Advanced Edit Mode" layer stack sidebar).
        /// </summary>
        /// <value>
        /// The toggle layers panel.
        /// </value>
        public ICommand ToggleLayersPanel { get; }

        /// <summary>
        /// Gets the command that turns the current single bitmap into a layered document. See
        /// <see cref="ImageView.EnableLayers"/> - a no-op if layers are already enabled or nothing is open.
        /// </summary>
        /// <value>
        /// The enable layers command.
        /// </value>
        public ICommand EnableLayers { get; }

        /// <summary>
        /// Gets the command that flattens and discards the current layered document. See
        /// <see cref="ImageView.DisableLayers"/>.
        /// </summary>
        /// <value>
        /// The disable layers command.
        /// </value>
        public ICommand DisableLayers { get; }

        /// <summary>
        /// Gets the GIF window.
        /// </summary>
        /// <value>
        /// The GIF window.
        /// </value>
        public ICommand GifWindow { get; }

        /// <summary>
        /// Gets the analyzer window.
        /// </summary>
        /// <value>
        /// The analyzer window.
        /// </value>
        public ICommand AnalyzerWindow { get; }

        /// <summary>
        /// Gets the export string.
        /// </summary>
        /// <value>
        /// The export string.
        /// </value>
        public ICommand ExportString { get; }

        public ICommand ResizerWindow { get; }
        public ICommand ApplyFilter { get; }
        public ICommand ApplyTexture { get; }
        public ICommand Brighten { get; }
        public ICommand Darken { get; }

        /// <summary>
        /// Gets the thumb image clicked.
        /// </summary>
        /// <value>
        /// The thumb image clicked.
        /// </value>
        public ICommand ThumbImageClicked { get; }

        /// <summary>
        /// Gets the image loaded.
        /// </summary>
        /// <value>
        /// The image loaded.
        /// </value>
        public ICommand ImageLoaded { get; }

        /// <summary>
        /// Gets the selected point.
        /// </summary>
        /// <value>
        /// The selected point.
        /// </value>
        public ICommand SelectedPoint { get; }

        /// <summary>
        /// Gets the selected frame.
        /// </summary>
        /// <value>
        /// The selected frame.
        /// </value>
        public ICommand SelectedFrame { get; }

        /// <summary>
        /// Gets the color changed.
        /// </summary>
        /// <value>
        /// The color changed.
        /// </value>
        public ICommand ColorChanged { get; }

        /// <summary>
        /// Gets the next.
        /// </summary>
        /// <value>
        /// The next.
        /// </value>
        public ICommand Next { get; }


        /// <summary>
        /// Gets the previous.
        /// </summary>
        /// <value>
        /// The previous.
        /// </value>
        public ICommand Previous { get; }

        /// <summary>
        /// Gets the show help.
        /// </summary>
        /// <value>
        /// The show help.
        /// </value>
        public ICommand ShowHelp { get; }

        /// <summary>
        /// Gets the show about.
        /// </summary>
        /// <value>
        /// The show about.
        /// </value>
        public ICommand ShowAbout { get; }

        /// <summary>
        /// Gets the undo.
        /// </summary>
        /// <value>
        /// The undo.
        /// </value>
        public ICommand Undo { get; }

        /// <summary>
        /// Gets the redo.
        /// </summary>
        /// <value>
        /// The redo.
        /// </value>
        public ICommand Redo { get; }

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageViewCommands"/> class.
        /// </summary>
        /// <param name="owner">The owning <see cref="ImageView"/> instance.</param>
        public ImageViewCommands(ImageView owner)
        {
            _owner = owner;

            // Uniform CanExecute
            bool CanRun<T>(T? arg) => owner.CanRun(arg);

            // ---- Helpers (explicit names matching parameter patterns) ----

            // No-parameter on service: Action<ImageView>
            DelegateCommand<object> MakeNoParamCmd(Action<ImageView> svcAction) =>
                new(_ => svcAction(owner), CanRun);

            // Service that expects (ImageView, object?)
            DelegateCommand<object> MakeObjParamCmd(Action<ImageView, object?> svcAction) =>
                new(p => svcAction(owner, p), CanRun);

            // Service that expects (ImageView, string?)
            DelegateCommand<string> MakeStringParamCmd(Action<ImageView, string?> svcAction) =>
                new(s => svcAction(owner, s), CanRun);

            // Bool? parameter commands
            DelegateCommand<bool?> MakeBoolParamCmd(Action<bool?> action) =>
                new(action, CanRun);

            // Async commands
            AsyncDelegateCommand<object> MakeAsyncObjCmd(Func<object?, Task> asyncAction) =>
                new(asyncAction, CanRun);

            // ---- UI / direct owner commands ----
            Close = new DelegateCommand<object>(owner.CloseAction, CanRun);
            OpenCbz = new DelegateCommand<object>(owner.OpenCbzAction, CanRun);
            GenerateAtlas = new DelegateCommand<object>(owner.GenerateAtlasAction, CanRun);
            Open = new DelegateCommand<object>(owner.OpenAction, CanRun);
            Refresh = new AsyncDelegateCommand<string>(owner.RefreshActionAsync, CanRun);
            Folder = new DelegateCommand<object>(owner.FolderAction, CanRun);
            Clear = new DelegateCommand<object>(owner.ClearAction, CanRun);
            OpenCif = new DelegateCommand<object>(owner.OpenCifAction, CanRun);
            ThumbImageClicked = new DelegateCommand<ImageEventArgs>(owner.ThumbImageClickedAction, CanRun);
            ImageLoaded = new DelegateCommand<object>(owner.ImageLoadedCommandAction, CanRun);
            ColorChanged = new DelegateCommand<ColorHsv>(owner.ColorChangedAction, CanRun);
            Next = new DelegateCommand<object>(owner.NextAction, CanRun);
            Previous = new DelegateCommand<object>(owner.PreviousAction, CanRun);
            Explorer = new DelegateCommand<object>(owner.ExplorerAction, CanRun);
            ExportString = new DelegateCommand<object>(owner.ExportStringAction, CanRun);
            Clipboard = new DelegateCommand<object>(owner.ExportClipboardAction, CanRun);
            ToggleCifEditor = new DelegateCommand<object>(owner.ToggleCifEditorAction, CanRun);
            ToggleFilterConfig = new DelegateCommand<object>(owner.ToggleFilterConfigAction, CanRun);
            ToggleTextureConfig = new DelegateCommand<object>(owner.ToggleTextureConfigAction, CanRun);
            ToggleLayersPanel = new DelegateCommand<object>(owner.ToggleLayersPanelAction, CanRun);
            EnableLayers = new DelegateCommand<object>(_ => owner.EnableLayers(), CanRun);
            DisableLayers = new DelegateCommand<object>(_ => owner.DisableLayers(), CanRun);

            SelectedPoint = new AsyncDelegateCommand<IReadOnlyList<Point>>(owner.SelectedPointAction, CanRun,
                ex => InMemoryLogger.Instance.Log(Core.MemoryLog.LogLevel.Warning, "Error in SelectedPoint",
                    libraryName: nameof(SelectedPoint), exception: ex));
            SelectedFrame = new AsyncDelegateCommand<SelectionFrame>(owner.SelectedFrameAction, CanRun,
                ex => InMemoryLogger.Instance.Log(Core.MemoryLog.LogLevel.Warning, "Error in SelectedFrame",
                    libraryName: nameof(SelectedFrame), exception: ex));

            // ---- UI / direct owner commands ----
            // AsyncDelegateCommand (not DelegateCommand) matters here: it disables
            // itself while a swap is in flight, so mashing Ctrl+Z can't start a
            // second Undo before the first one has finished. A plain DelegateCommand
            // would also silently discard the Task UndoAsync/RedoAsync return.
            Undo = MakeAsyncObjCmd(_ => owner.UndoAsync());
            Redo = MakeAsyncObjCmd(_ => owner.RedoAsync());

            // ---- Image mass processing (service methods mostly take ImageView or ImageView+param) ----
            Scale = MakeNoParamCmd(_imageMassService.ScaleWindow);
            FolderConvert = MakeNoParamCmd(_imageMassService.FolderConvertWindow);
            FolderRename = MakeNoParamCmd(_imageMassService.FolderRenameWindow);
            FindDuplicates = MakeNoParamCmd(_imageMassService.FindDuplicatesWindow);
            FolderSearch = MakeNoParamCmd(_imageMassService.FolderSearch);
            ResizerWindow = MakeNoParamCmd(_imageMassService.ResizerWindow);
            AnalyzerWindow = MakeNoParamCmd(_imageMassService.AnalyzerWindow);
            ShowHelp = MakeNoParamCmd(_imageMassService.ShowHelp);
            ShowAbout = MakeNoParamCmd(_imageMassService.ShowAbout);
            GifWindow = MakeStringParamCmd(_imageMassService.GifWindow);

            // ---- Image processing (service methods that take owner + param) ----
            Brighten = MakeStringParamCmd(_imageService.Brighten);
            Darken = MakeStringParamCmd(_imageService.Darken);

            ApplyFilter = MakeStringParamCmd(_imageService.ApplyFilter);
            ApplyTexture = MakeStringParamCmd(_imageService.ApplyTexture);

            // Many image ops accept (ImageView, object?) in your original code
            Mirror = MakeObjParamCmd(_imageService.Mirror);
            RotateForward = MakeObjParamCmd(_imageService.RotateForward);
            RotateBackward = MakeObjParamCmd(_imageService.RotateBackward);
            Pixelate = MakeObjParamCmd(_imageService.Pixelate);

            // ---- File operations (service methods generally accept ImageView + param) ----
            Delete = MakeAsyncObjCmd(obj => FileService.DeleteAsync(owner));
            Move = MakeObjParamCmd(FileService.Move);
            MoveAll = MakeObjParamCmd(FileService.MoveAll);


            // Rename is asynchronous in your original; pass the owner in the lambda to call the service method
            Rename = MakeAsyncObjCmd(obj => FileService.RenameCurrentAsync(owner));

            ConvertCif = MakeObjParamCmd(FileService.ConvertCif);

            // CleanTempFolder expects bool? (original: CleanTempAction(bool? obj) => _fileService.CleanTempFolder(obj))
            CleanTempFolder = MakeBoolParamCmd(FileService.CleanTempFolder);

            Save = MakeObjParamCmd(FileService.Save);
        }
    }
}