﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViews.Tooling
 * FILE:        Compare.xaml.cs
 * PURPOSE:     Basic Compare Window
 * PROGRAMER:   Peter Geinitz (Wayfarer)
 */

using System.Collections.Generic;
using System.Windows;

namespace SlimViews.Tooling
{
    /// <inheritdoc cref="Window" />
    /// <summary>
    ///     Result Set for Image Comparer
    /// </summary>
    internal sealed partial class Compare
    {
        /// <summary>
        /// The view model
        /// </summary>
        private readonly CompareView _viewModel;

        /// <inheritdoc />
        /// <summary>
        ///     Initializes a new instance of the <see cref="Compare" /> class.
        /// </summary>
        public Compare()
        {
            InitializeComponent();
            _viewModel = new CompareView();
            DataContext = _viewModel;
        }

        /// <inheritdoc />
        /// <summary>
        ///     Initializes a new instance of the <see cref="Compare" /> class for a single folder.
        /// </summary>
        public Compare(bool subFolders, string? currentFolder, ImageView? imageView, int similarity = 0)
        {
            InitializeComponent();
            _viewModel = new CompareView();
            DataContext = _viewModel;

            _ = _viewModel.AsyncInitiate(subFolders, currentFolder, similarity, imageView);
        }

        /// <inheritdoc />
        /// <summary>
        ///     Initializes a new instance of the <see cref="Compare" /> class across one or more
        ///     folders, searched together as a single pool.
        /// </summary>
        public Compare(bool subFolders, IReadOnlyCollection<string>? folders, ImageView? imageView,
            int similarity = 0)
        {
            InitializeComponent();
            _viewModel = new CompareView();
            DataContext = _viewModel;

            _ = _viewModel.AsyncInitiate(subFolders, folders, similarity, imageView);
        }
    }
}