﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViews.Tooling
 * FILE:        DuplicateGroupModel.cs
 * PURPOSE:     View over each group of duplicate images, containing the image paths and commands for actions on the group (delete, rename, etc.)
 * PROGRAMER:   Peter Geinitz (Wayfarer)
 */

using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Windows.Input;
using ViewModel;

namespace SlimViews.Tooling
{
    /// <summary>
    /// View model representing a group of duplicate images, containing the image paths and commands for actions on the group (delete, rename, etc.)
    /// </summary>
    /// <seealso cref="ViewModel.ViewModelBase" />
    public class DuplicateGroupModel : ViewModelBase
    {
        /// <summary>
        /// The images
        /// </summary>
        private Dictionary<int, string?> _images = new();

        /// <summary>
        /// The similarity scores
        /// </summary>
        private Dictionary<int, int> _similarityScores = new();

        /// <summary>
        /// The new name
        /// </summary>
        private string? _newName;

        /// <summary>
        /// The group identifier
        /// </summary>
        private readonly string? _groupId;

        /// <summary>
        /// Gets the group identifier.
        /// </summary>
        /// <value>
        /// The group identifier.
        /// </value>
        public string? GroupId
        {
            get => _groupId;
            init => SetProperty(ref _groupId, value, nameof(GroupId));
        }

        /// <summary>
        ///     The raw path list this card was built from - the very same <see cref="List{T}" />
        ///     instance stored in CompareView's master <c>_duplicates</c> list. Kept purely as an
        ///     identity key so a single card can be found and swapped out without rebuilding
        ///     every other card on the page (see CompareView.RemoveGroupFromMaster).
        /// </summary>
        internal List<string?>? SourcePaths { get; init; }

        /// <summary>
        /// Gets or sets the images.
        /// </summary>
        /// <value>
        /// The images.
        /// </value>
        public Dictionary<int, string?> Images
        {
            get => _images;
            set => SetProperty(ref _images, value, nameof(Images));
        }

        /// <summary>
        /// Gets or sets the similarity scores.
        /// </summary>
        /// <value>
        /// The similarity scores.
        /// </value>
        public Dictionary<int, int> SimilarityScores
        {
            get => _similarityScores;
            set => SetProperty(ref _similarityScores, value, nameof(SimilarityScores));
        }

        /// <summary>
        /// Creates new name.
        /// </summary>
        /// <value>
        /// The new name.
        /// </value>
        public string? NewName
        {
            get => _newName;
            set => SetProperty(ref _newName, value, nameof(NewName));
        }

        /// <summary>
        /// Gets the selection.
        /// </summary>
        /// <value>
        /// The selection.
        /// </value>
        public ConcurrentDictionary<int, bool> Selection { get; } = new();

        /// <summary>
        /// Gets or sets the delete selected command.
        /// </summary>
        /// <value>
        /// The delete selected command.
        /// </value>
        public ICommand? DeleteSelectedCommand { get; set; }

        /// <summary>
        /// Gets or sets the rename selected command.
        /// </summary>
        /// <value>
        /// The rename selected command.
        /// </value>
        public ICommand? RenameSelectedCommand { get; set; }


        /// <summary>
        /// Gets or sets the delete all command.
        /// </summary>
        /// <value>
        /// The delete all command.
        /// </value>
        public ICommand? DeleteAllCommand { get; set; }

        /// <summary>
        /// Gets or sets the "ignore this group for the current session" command. Dismisses the
        /// group from the list without touching any files on disk; it comes back on the next
        /// app run (or if it's not re-added at all, see CompareView's ignore-signature set).
        /// </summary>
        /// <value>
        /// The ignore group command.
        /// </value>
        public ICommand? IgnoreGroupCommand { get; set; }
    }
}