﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     SlimViews.Tooling
 * FILE:        CompareView.cs
 * PURPOSE:     View Model for the Comparer
 * PROGRAMER:   Peter Geinitz (Wayfarer)
 */

// ReSharper disable MemberCanBePrivate.Global

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Common.Images;
using Imaging;
using Imaging.Compare;
using Imaging.Gifs;
using ViewModel;

namespace SlimViews.Tooling
{
    /// <inheritdoc />
    /// <summary>
    ///     ViewModel for comparing images. Handles paging through duplicates or similar images
    ///     and provides DuplicateGroups for data binding in the Compare Window.
    /// </summary>
    internal sealed class CompareView : ViewModelBase
    {
        /// <summary>
        ///     Image comparer utility for finding duplicates or similar images.
        /// </summary>
        private readonly ImageComparer _compare = new();

        /// <summary>
        ///     Current page index (0-based).
        /// </summary>
        private int _index;

        /// <summary>
        ///     Total number of pages.
        /// </summary>
        private int _rows;

        /// <summary>
        ///     Status text displayed in the UI.
        /// </summary>
        private string? _status;

        /// <summary>
        ///     Whether a scan, delete, or rename is currently running.
        /// </summary>
        private bool _isBusy;

        /// <summary>
        /// The selected image path
        /// </summary>
        private string? _selectedImagePath;

        /// <summary>
        ///     Holds the raw duplicate or similar image paths.
        ///     Each inner list represents a single observer group.
        /// </summary>
        private List<List<string>>? _duplicates;

        /// <summary>
        ///     Signatures (see <see cref="GetGroupSignature" />) of groups the user has dismissed
        ///     with "Ignore for Session". Session-only by design - it's cleared the moment the app
        ///     restarts, since a later run might reasonably want to see these again.
        /// </summary>
        private readonly HashSet<string> _ignoredGroupSignatures = new(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// The current selected image information
        /// </summary>
        private string? _currentSelectedImageInfo;

        /// <summary>
        /// The thumb image clicked
        /// </summary>
        private DelegateCommand<object>? _thumbImageClicked;

        /// <summary>
        /// Gets or sets the current selected image information.
        /// </summary>
        /// <value>
        /// The current selected image information.
        /// </value>
        public string CurrentSelectedImageInfo
        {
            get => _currentSelectedImageInfo;
            set => SetProperty(ref _currentSelectedImageInfo, value, nameof(CurrentSelectedImageInfo));
        }

        /// <summary>
        /// Gets or sets the path of the currently selected image for the preview panel.
        /// </summary>
        /// <value>
        /// The selected image path.
        /// </value>
        public string? SelectedImagePath
        {
            get => _selectedImagePath;
            set => SetProperty(ref _selectedImagePath, value, nameof(SelectedImagePath));
        }

        /// <summary>
        /// The image view
        /// </summary>
        private ImageView _imageView;

        /// <summary>
        /// Gets or sets the status text.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status
        {
            get => _status;
            set => SetProperty(ref _status, value, nameof(Status));
        }

        /// <summary>
        /// Gets or sets a value indicating whether a scan, delete, or rename is currently running.
        /// Drives the pulsing <see cref="Common.Images.BusyIndicator" /> in the Compare window.
        /// </summary>
        /// <value>
        ///   <c>true</c> if busy; otherwise, <c>false</c>.
        /// </value>
        public bool IsBusy
        {
            get => _isBusy;
            set => SetProperty(ref _isBusy, value, nameof(IsBusy));
        }

        /// <summary>
        /// Gets the current image identifier.
        /// </summary>
        /// <value>
        /// The current image identifier.
        /// </value>
        public int CurrentImageId { get; private set; }

        /// <summary>
        /// Gets the duplicate groups.
        /// </summary>
        /// <value>
        /// The duplicate groups.
        /// </value>
        public ObservableCollection<DuplicateGroupModel> DuplicateGroups { get; } = new();

        /// <summary>
        /// Gets the thumb image clicked.
        /// This handles the metadata display when an image is clicked
        /// </summary>
        /// <value>
        /// The thumb image clicked.
        /// </value>
        public ICommand ThumbImageClicked => _thumbImageClicked ??= new DelegateCommand<object>(param =>
        {
            if (param is ImageEventArgs args)
            {
                var group = DuplicateGroups.FirstOrDefault(g => g.GroupId == args.SenderTag);

                if (group is { } && group.Images.TryGetValue(args.Id, out var path))
                {
                    if (File.Exists(path))
                    {
                        group.NewName = Path.GetFileNameWithoutExtension(path);
                        UpdateImageMetadata(path);
                        CurrentImageId = args.Id;

                        SelectedImagePath = path;
                    }
                }
            }
        });

        /// <summary>
        /// Command to navigate to the previous page of images.
        /// </summary>
        /// <value>
        /// The previous command.
        /// </value>
        public ICommand PreviousCommand =>
            _previousCommand ??= new DelegateCommand<object>(PreviousAction, _ => _index > 0);

        /// <summary>
        ///     Command to navigate to the next page of images.
        /// </summary>
        public ICommand NextCommand =>
            _nextCommand ??= new DelegateCommand<object>(NextAction, _ => _index < _rows - 1);

        /// <summary>
        /// The previous command
        /// </summary>
        private ICommand? _previousCommand;

        /// <summary>
        /// The next command
        /// </summary>
        private ICommand? _nextCommand;

        /// <summary>
        /// Initiates the comparison asynchronously against a single folder. Kept for existing
        /// callers - delegates to the multi-folder overload below with a one-item folder list.
        /// </summary>
        /// <param name="subFolders">Include subfolders if true.</param>
        /// <param name="currentFolder">The folder to scan.</param>
        /// <param name="similarity">Similarity threshold in percent. 0 = exact duplicates.</param>
        /// <param name="imageView">The image view.</param>
        internal async Task AsyncInitiate(bool subFolders, string? currentFolder, int similarity = 0,
            ImageView? imageView = null)
        {
            var folders = string.IsNullOrWhiteSpace(currentFolder)
                ? Array.Empty<string>()
                : new[] { currentFolder };

            await AsyncInitiate(subFolders, folders, similarity, imageView);
        }

        /// <summary>
        /// Initiates the comparison asynchronously across one or more folders.
        /// Retrieves duplicates or similar images and populates observer groups.
        /// </summary>
        /// <param name="subFolders">Include subfolders if true.</param>
        /// <param name="folders">The folders to scan, searched together as a single pool.</param>
        /// <param name="similarity">Similarity threshold in percent. 0 = exact duplicates.</param>
        /// <param name="imageView">The image view.</param>
        internal async Task AsyncInitiate(bool subFolders, IReadOnlyCollection<string> folders, int similarity = 0,
            ImageView? imageView = null)
        {
            _imageView = imageView;
            IsBusy = true;

            try
            {
                if (folders == null || folders.Count == 0)
                {
                    Status = "No folder selected to search.";
                    return;
                }

                // UI Feedback: Let the user know exactly what kind of search is running
                var folderLabel = folders.Count == 1 ? "folder" : $"folders: {folders.Count}";
                Status = similarity == 0
                    ? $"Scanning {folderLabel} for duplicates..."
                    : $"Scanning {folderLabel} for {similarity}% similarity...";

                _duplicates = await Task.Run(() =>
                {
                    // This is the "Tricky" part:
                    // similarity == 0 means bit-for-bit check
                    // similarity > 0 means visual histogram/perceptual check
                    var results = similarity == 0
                        ? _compare.GetDuplicateImages(folders, subFolders, ImagingResources.Appendix)
                        : _compare.GetSimilarImages(folders, subFolders, ImagingResources.Appendix, similarity);

                    // Drop any group the user explicitly dismissed earlier this session
                    // ("Ignore for Session") so a rescan doesn't just bring it straight back.
                    return results?.Where(g => !_ignoredGroupSignatures.Contains(GetGroupSignature(g))).ToList();
                }).ConfigureAwait(false);

                if (_duplicates == null || _duplicates.Count == 0)
                {
                    Status = "No matching images found.";
                    return;
                }

                // Ceiling division for pagination
                _rows = (_duplicates.Count + 9) / 10;
                _index = 0;

                // Trigger the UI thread update
                Application.Current.Dispatcher.Invoke(() =>
                {
                    GenerateView();
                    Status = $"Found {_duplicates.Count} groups of matches.";
                });
            }
            finally
            {
                IsBusy = false;
            }
        }

        /// <summary>
        ///     Navigate to the next page of images.
        /// </summary>
        /// <param name="_">Unused command parameter.</param>
        private void NextAction(object _)
        {
            if (_index < _rows - 1)
            {
                _index++;
                GenerateView();
            }
        }

        /// <summary>
        ///     Navigate to the previous page of images.
        /// </summary>
        /// <param name="_">Unused command parameter.</param>
        private void PreviousAction(object _)
        {
            if (_index > 0)
            {
                _index--;
                GenerateView();
            }
        }

        /// <summary>
        /// Generates the observer groups for the current page.
        /// Updates each dictionary in-place to preserve WPF bindings.
        /// </summary>
        private void GenerateView()
        {
            if (_duplicates == null || _duplicates.Count == 0) return;

            DuplicateGroups.Clear();

            var baseIndex = _index * 10;

            for (var i = 0; i < 10; i++)
            {
                List<string?>? groupPaths = _duplicates.ElementAtOrDefault(baseIndex + i);
                if (groupPaths == null || groupPaths.Count == 0) continue;

                DuplicateGroups.Add(BuildGroupModel(groupPaths, i));
            }
        }

        /// <summary>
        ///     Builds a single group card (model + its command bindings) from a raw path list.
        ///     Pulled out of <see cref="GenerateView" /> so a single card can be (re)built on its
        ///     own - see <see cref="RemoveGroupFromMaster" /> - without having to rebuild every
        ///     other card on the page along with it.
        /// </summary>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        /// <param name="slotHint">Used only to build a human-readable <see cref="DuplicateGroupModel.GroupId" />.</param>
        private DuplicateGroupModel BuildGroupModel(List<string?> groupPaths, int slotHint)
        {
            var groupModel = new DuplicateGroupModel
            {
                GroupId = $"Group_{slotHint}",
                NewName = Path.GetFileNameWithoutExtension(groupPaths[0]),
                SourcePaths = groupPaths
            };

            // ---> Bind the UI buttons to the ViewModel logic <---
            groupModel.DeleteAllCommand =
                new DelegateCommand<object>(async _ => await DeleteGroupAsync(groupModel, groupPaths));
            groupModel.DeleteSelectedCommand =
                new DelegateCommand<object>(async param =>
                    await DeleteSelectedAsync(groupModel, param, groupPaths));
            groupModel.RenameSelectedCommand =
                new DelegateCommand<object>(async param =>
                    await RenameSelectedAsync(groupModel, param, groupPaths));
            groupModel.IgnoreGroupCommand =
                new DelegateCommand<object>(_ => IgnoreGroup(groupModel, groupPaths));

            var imageDict = new Dictionary<int, string?>();
            var localId = 0;
            foreach (var path in groupPaths)
            {
                imageDict.Add(localId++, path);
            }

            groupModel.Images = imageDict;
            return groupModel;
        }

        /// <summary>
        ///     Builds a stable signature for a group of file paths, independent of ordering or of
        ///     which page/index the group currently occupies - used to remember dismissed groups
        ///     across pagination and rescans within the same session.
        /// </summary>
        /// <param name="paths">The file paths making up the group.</param>
        private static string GetGroupSignature(IEnumerable<string?> paths) =>
            string.Join("|", paths.Where(p => p is { }).OrderBy(p => p, StringComparer.OrdinalIgnoreCase));

        /// <summary>
        ///     Removes a whole raw group from <see cref="_duplicates" /> (e.g. once it's fully
        ///     deleted, ignored, or has dropped to 0-1 remaining images) and keeps pagination
        ///     (<see cref="_rows" />/<see cref="_index" />) consistent, then refreshes the visible
        ///     page. This is what actually stops a stale/broken group from reappearing - with
        ///     deleted files showing up as gray/broken thumbnails - the moment the user pages away
        ///     and back, since <see cref="GenerateView" /> always rebuilds strictly from
        ///     <see cref="_duplicates" />.
        /// </summary>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        private void RemoveGroupFromMaster(List<string?> groupPaths)
        {
            _ = (_duplicates?.Remove(groupPaths));

            if (_duplicates == null || _duplicates.Count == 0)
            {
                _rows = 0;
                _index = 0;
                DuplicateGroups.Clear();
                Status = "No matching images found.";
                return;
            }

            _rows = (_duplicates.Count + 9) / 10;
            if (_index > _rows - 1) _index = Math.Max(0, _rows - 1);

            // This used to be a flat call to GenerateView(), which clears and rebuilds all 10
            // cards on the current page - meaning every group's Thumbnails control reloaded every
            // image from disk again, just because ONE group was deleted or ignored. With big
            // images or many groups that's most of what made Compare "take forever" to rebuild.
            // Instead, find just the affected card and swap it out on its own; every other card
            // on the page is left completely alone.
            var cardIndex = -1;
            for (var i = 0; i < DuplicateGroups.Count; i++)
            {
                if (!ReferenceEquals(DuplicateGroups[i].SourcePaths, groupPaths)) continue;

                cardIndex = i;
                break;
            }

            if (cardIndex < 0)
            {
                // Couldn't find the card (shouldn't normally happen) - fall back to the safe,
                // if slower, full rebuild rather than leaving the view out of sync.
                GenerateView();
                Status = $"Found {_duplicates.Count} groups of matches.";
                return;
            }

            DuplicateGroups.RemoveAt(cardIndex);

            // If the master list still has a group beyond what's currently shown on this page,
            // slot it in where the removed card was, so the page stays full at up to 10 groups.
            var baseIndex = _index * 10;
            var nextGroupPaths = _duplicates.ElementAtOrDefault(baseIndex + DuplicateGroups.Count);
            if (nextGroupPaths is { Count: > 0 })
            {
                DuplicateGroups.Insert(cardIndex, BuildGroupModel(nextGroupPaths, cardIndex));
            }

            Status = $"Found {_duplicates.Count} groups of matches.";
        }

        /// <summary>
        ///     Dismisses a duplicate/similar group for the rest of this session: it disappears from
        ///     the list immediately, pagination is recalculated, and it won't reappear even if the
        ///     folder is rescanned again - but nothing is deleted, and a fresh app run will see it
        ///     again as usual.
        /// </summary>
        /// <param name="group">The group card being dismissed.</param>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        private void IgnoreGroup(DuplicateGroupModel group, List<string?> groupPaths)
        {
            _ignoredGroupSignatures.Add(GetGroupSignature(groupPaths));
            RemoveGroupFromMaster(groupPaths);
        }

        /// <summary>
        /// Deletes the group asynchronous.
        /// </summary>
        /// <param name="group">The group.</param>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        private async Task DeleteGroupAsync(DuplicateGroupModel group, List<string?> groupPaths)
        {
            IsBusy = true;
            try
            {
                // Release the UI lock if the currently previewed image is in this group
                if (group.Images.ContainsValue(SelectedImagePath))
                {
                    SelectedImagePath = null;
                    await Task.Yield(); // Give WPF a tick to let go
                }

                // kvp.Value is the file path string
                await _imageView.Commands.FileService.DeleteAsync(_imageView, group.Images.Values.ToList(), false);

                // The whole group is gone now - drop it from the master list too (not just the
                // live UI dictionary), otherwise paging away and back rebuilds this exact card
                // from the stale raw path list and shows every image as a broken/gray thumbnail.
                group.Images = new Dictionary<int, string?>();
                RemoveGroupFromMaster(groupPaths);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }
        }

        /// <summary>
        /// Deletes the image asynchronous.
        /// </summary>
        /// <param name="group">The group.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        private async Task DeleteSelectedAsync(DuplicateGroupModel group, object parameter, List<string?> groupPaths)
        {
            // 1. Validate and extract selection
            if (parameter is not ConcurrentDictionary<int, bool> selection)
            {
                Trace.WriteLine("DeleteSelectedAsync: Invalid parameter type.");
                return;
            }

            IsBusy = true;
            try
            {
                // 2. Handle empty selection (Default to current image)
                if (selection.IsEmpty)
                {
                    selection.AddOrUpdate(CurrentImageId, true, (key, oldValue) => true);
                }

                var selectedKeys = selection.Where(kvp => kvp.Value).Select(kvp => kvp.Key).ToList();
                if (selectedKeys.Count == 0)
                {
                    selectedKeys.Add(CurrentImageId);
                }

                // Release the UI lock if the image we are previewing is about to be deleted
                if (selectedKeys.Any(k => group.Images.TryGetValue(k, out var p) && p == SelectedImagePath))
                {
                    SelectedImagePath = null;
                    await Task.Yield(); // Give WPF's binding engine a tick to release the image control
                }

                var updatedImages = new Dictionary<int, string?>(group.Images);
                var deletedCount = 0;
                var deletedPaths = new List<string?>();

                foreach (var key in selectedKeys)
                {
                    if (group.Images.TryGetValue(key, out var path))
                    {
                        try
                        {
                            // isSilent: true - deleting each selected file one-by-one would otherwise pop
                            // up a separate "1 file(s) deleted" message box per item. We show a single
                            // summary message for the whole batch below instead.
                            await _imageView.Commands.FileService.DeleteAsync(_imageView, new List<string?> { path },
                                true);

                            deletedCount++;
                            updatedImages.Remove(key);
                            deletedPaths.Add(path);
                            // Note: don't mutate group.Images (the live, bound dictionary) here - it can
                            // still be enumerated by an in-flight thumbnail rebuild. We swap it out for
                            // updatedImages once, below, after the whole batch is done.
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine($"Failed to delete {path}: {ex.Message}");
                        }
                    }
                }

                // Keep the master list (_duplicates) in sync with what's actually still on disk -
                // groupPaths is the very same List<string> object stored inside _duplicates, so
                // this is what stops a paged-away-and-back visit from rebuilding the group with
                // the deleted file(s) still in it (shown as broken/gray thumbnails).
                foreach (var deletedPath in deletedPaths)
                {
                    groupPaths.Remove(deletedPath);
                }

                // 5. Update UI State
                group.Images = updatedImages;
                selection.Clear();

                if (deletedCount > 0)
                {
                    MessageBox.Show($"{ViewResources.MessageCount}{deletedCount}", ViewResources.MessageSuccess);
                }

                if (group.Images.Count <= 1)
                {
                    // Not enough images left for this to be a meaningful duplicate/similar group -
                    // drop it from the master list too so it can't reappear later this session.
                    RemoveGroupFromMaster(groupPaths);
                }
            }
            finally
            {
                IsBusy = false;
            }
        }

        /// <summary>
        /// Renames the selected asynchronous.
        /// </summary>
        /// <param name="group">The group.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="groupPaths">The group's raw file paths, as stored in <see cref="_duplicates" />.</param>
        private async Task RenameSelectedAsync(DuplicateGroupModel group, object parameter, List<string?> groupPaths)
        {
            if (parameter is not ConcurrentDictionary<int, bool> selection || string.IsNullOrWhiteSpace(group.NewName))
                return;

            IsBusy = true;
            try
            {
                var selectedKeys = selection.Where(kvp => kvp.Value).Select(kvp => kvp.Key).ToList();
                if (selectedKeys.Count == 0) selectedKeys.Add(CurrentImageId);

                var updatedImages = new Dictionary<int, string?>(group.Images);
                var anySuccess = false;

                // Track if we are renaming the currently previewed image
                var isPreviewingRenamedImage = false;

                foreach (var key in selectedKeys)
                {
                    if (group.Images.TryGetValue(key, out var sourcePath))
                    {
                        var extension = Path.GetExtension(sourcePath);
                        var directory = Path.GetDirectoryName(sourcePath);
                        var targetPath = Path.Combine(directory, group.NewName + extension);

                        // Drop the CompareView lock if this is the active preview image
                        if (sourcePath == SelectedImagePath)
                        {
                            SelectedImagePath = null;
                            isPreviewingRenamedImage = true;
                            await Task.Yield(); // Give WPF a tick to release the file handle
                        }

                        // Use the Owner's FileService to ensure the main viewer is cleared
                        var newPath =
                            await _imageView.Commands.FileService.RenameAsync(_imageView, sourcePath, targetPath,
                                isSilent: true);

                        if (newPath is { })
                        {
                            updatedImages[key] = newPath;
                            anySuccess = true;

                            // Keep the master list (_duplicates) in sync too - groupPaths is the
                            // same List<string> object stored inside _duplicates, so without this
                            // a paged-away-and-back visit would rebuild the group with the old,
                            // now-nonexistent path and show it as a broken/gray thumbnail.
                            var rawIndex = groupPaths.IndexOf(sourcePath);
                            if (rawIndex >= 0) groupPaths[rawIndex] = newPath;

                            //  Restore the preview using the new file path!
                            if (isPreviewingRenamedImage)
                            {
                                SelectedImagePath = newPath;
                                isPreviewingRenamedImage = false; // Reset flag
                            }
                        }
                        else if (isPreviewingRenamedImage)
                        {
                            // If rename failed for some reason, put the old preview back
                            SelectedImagePath = sourcePath;
                            isPreviewingRenamedImage = false;
                        }
                    }
                }

                if (anySuccess)
                {
                    group.Images = updatedImages;
                    Status = "Rename complete.";
                }
            }
            finally
            {
                IsBusy = false;
            }
        }

        /// <summary>
        /// Updates the image metadata.
        /// </summary>
        /// <param name="path">The path.</param>
        private void UpdateImageMetadata(string? path)
        {
            try
            {
                var fileName = Path.GetFileName(path);
                string infoBody;

                // Check if the file is a GIF
                if (Path.GetExtension(path).Equals(".gif", StringComparison.OrdinalIgnoreCase))
                {
                    // Assuming you have a way to load or retrieve the ImageGifInfo for the path
                    var gifData = ImageGifHandler.GetImageInfo(path);
                    infoBody = ViewResources.BuildUnifiedImageInfo(path, fileName, gifData);
                }
                else
                {
                    var bitmap = ImagingFacade.LoadBitmapImage(path);
                    infoBody = ViewResources.BuildUnifiedImageInfo(path, fileName, bitmap);
                }

                var score = GetScoreForPath(path);

                // Combine the multiline body with the similarity score
                CurrentSelectedImageInfo = $"{infoBody}{Environment.NewLine}Similarity: {score}%";
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Metadata Error: {ex.Message}");
            }
        }

        /// <summary>
        /// Gets the score for path.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>Information about images.</returns>
        private int GetScoreForPath(string? path)
        {
            // Look through all groups to find which one contains this image
            var group = DuplicateGroups.FirstOrDefault(g => g.Images.Values.Contains(path));
            if (group is { })
            {
                // Find the key (ID) for this path to get the matching score
                var key = group.Images.FirstOrDefault(x => x.Value == path).Key;
                if (group.SimilarityScores.TryGetValue(key, out var score))
                {
                    return score;
                }
            }

            return 100; // Default for the "original" or if not found
        }
    }
}